# NSEScanner Phase-0 Truth and Safety Patch

This archive is path-preserving. Extract it at the root of the complete MarketScannerByDev repository on a new branch, then review and test every change.

## What it changes

- current NIFTY/BANKNIFTY/SENSEX expiry conventions across production/backtest code;
- exact trade-grade F&O contract/token enforcement;
- fail-closed option-chain, liquidity, database, cost/edge and ledger gates;
- Kite-first Swing levels, trigger-time entry and Yahoo execution blocking;
- scanner provenance, sector and special-series filtering;
- OI market-state/zero-change narrative truth;
- option exercise/payoff/suggestion labels;
- 2026 charges, session/holiday and macro-event facts;
- period/lifetime report consistency;
- owner authorization and Telegram mode-alert copy;
- UI reason maps and ledger capital-movement visibility.

## Safety

The patch does not enable broker execution and does not modify a live database. It does not repair the observed historical ledger drift automatically. Both paper entry lanes reject new opens when reconciliation fails; exits remain available.

## Required complete-repository verification

The uploaded audit export lacked the root package manifest, lockfile, test config, Git metadata and migrations. Run the full repo's lockfile install, migrations, typecheck, test suite, build and authenticated browser smoke tests before deployment. Follow `reports/REPLIT_CODER_PHASE_0_AND_REMEDIATION_PROMPT_2026-07-18.md`.

## Do not

- enable live/broker execution;
- reset balances or rewrite trade history;
- lower safety thresholds to create more signals;
- permit Yahoo/fallback data to open trades;
- trade a nearest/corrected contract without an exact instrument-master match;
- claim profitability or production readiness from a syntax pass.
