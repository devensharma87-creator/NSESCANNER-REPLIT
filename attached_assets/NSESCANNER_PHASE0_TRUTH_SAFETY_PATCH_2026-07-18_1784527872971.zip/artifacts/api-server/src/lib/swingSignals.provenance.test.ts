import { describe, expect, it } from "vitest";
import type { StockRow } from "@workspace/api-zod";
import { isTradeGradeSwingRow } from "./swingSignals";

function row(overrides: Record<string, unknown> = {}): StockRow {
  return {
    symbol: "RELIANCE",
    rowSource: {
      symbol: "RELIANCE",
      source: "kite",
      sourceStatus: "TRADE_GRADE",
      asOf: new Date().toISOString(),
      freshnessSec: 1,
      canDriveSignals: true,
      canDriveTradeAlerts: true,
      warning: null,
    },
    provenance: {
      sourceProvider: "kite",
      sourceLabel: "Kite",
      asOf: Math.floor(Date.now() / 1000),
      timeframe: "15m",
      freshnessSec: 1,
      delayed: false,
      isStale: false,
      authoritative: true,
      notForSignals: false,
      notForTradeDecisions: false,
      warnings: [],
    },
    ...overrides,
  } as unknown as StockRow;
}

describe("isTradeGradeSwingRow", () => {
  it("accepts only a fresh Kite row whose signal and alert flags are enabled", () => {
    expect(isTradeGradeSwingRow(row())).toBe(true);
  });

  it("rejects Yahoo research rows even when a live Kite price was overlaid", () => {
    const candidate = row({
      rowSource: {
        symbol: "RELIANCE",
        source: "yahoo",
        sourceStatus: "INFO_ONLY",
        canDriveSignals: false,
        canDriveTradeAlerts: false,
      },
      provenance: {
        sourceProvider: "yahoo",
        isStale: false,
        delayed: true,
        notForSignals: true,
        notForTradeDecisions: true,
      },
    });
    expect(isTradeGradeSwingRow(candidate)).toBe(false);
  });

  it("fails closed for legacy rows with missing provenance", () => {
    expect(isTradeGradeSwingRow(row({ rowSource: undefined }))).toBe(false);
    expect(isTradeGradeSwingRow(row({ provenance: undefined }))).toBe(false);
  });
});
