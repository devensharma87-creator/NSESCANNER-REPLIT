/**
 * F&O Signal Reasoning Logger (Priority P14 — 2026-05-15).
 *
 * **Diagnostics-only.** This module writes append-only rows to
 * `fno_signal_reasoning` describing every verdict the F&O paper-trade
 * decision pipeline emits. It does NOT alter any signal, gate, sizing,
 * execution, scheduler, or scanner decision.
 *
 * Safety contract:
 *
 *   1. Every public function is non-throwing. Any DB or shape error is
 *      caught, logged at WARN, and discarded. A reasoning-logger outage
 *      CANNOT block trading.
 *
 *   2. Callers should fire-and-forget. The intended idiom is:
 *
 *          void logFnoReasoning({...}); // sync call sites
 *          await logFnoReasoning({...}); // async call sites (still safe)
 *
 *      The function never rejects.
 *
 *   3. The writer does NOT validate that fields refer to real signals.
 *      That is intentional — the caller is the source of truth for the
 *      reasoning payload, and we'd rather record an imperfect row than
 *      drop a diagnostic event on a schema mismatch.
 *
 *   4. No secrets, tokens, API keys, or PII are accepted by the payload
 *      shape. The catch-all `snapshot` is opaque JSONB, but it is the
 *      caller's responsibility never to put credentials there. Reviewer
 *      check: search `fnoSignalReasoningLogger` call sites — none pass
 *      session/token/credential objects.
 *
 * The query helpers below back the owner-only diagnostic route in
 * `routes/paper.ts`. They are read-only.
 */

import { db, fnoSignalReasoningTable } from "@workspace/db";
import type {
  FnoSignalReasoningRow,
  NewFnoSignalReasoningRow,
} from "@workspace/db";
import { and, asc, desc, eq, gte, lte, sql } from "drizzle-orm";
import { logger } from "./logger";
import {
  CURRENT_WRITER_VERSION,
  isReasoningWriterV2Enabled,
  mapDecisionToCanonical,
  mapDemotionTagsToCanonicalReason,
  type CanonicalDecision,
  type CanonicalReason,
  type TradeClass,
} from "./fnoCanonicalTaxonomy";

/* ──────────────────── P17a observability counters ────────────────────
 * In-memory counters so an owner-only health endpoint can answer
 * "is the reasoning logger actually writing?" without having to grep
 * server logs. These are process-local and reset on restart — that
 * is the desired semantic (we want to know what THIS process has
 * done since boot). No DB writes, no decision impact.
 */
interface ReasoningLoggerHealth {
  writesAttempted: number;
  writesSucceeded: number;
  writesFailed: number;
  lastSuccessAt: string | null;
  lastErrorAt: string | null;
  lastErrorClass: string | null;
  lastErrorMessage: string | null;
  bootedAt: string;
}
const HEALTH: ReasoningLoggerHealth = {
  writesAttempted: 0,
  writesSucceeded: 0,
  writesFailed: 0,
  lastSuccessAt: null,
  lastErrorAt: null,
  lastErrorClass: null,
  lastErrorMessage: null,
  bootedAt: new Date().toISOString(),
};
/** Snapshot of the reasoning-logger health counters. Read-only. */
export function getReasoningLoggerHealth(): Readonly<ReasoningLoggerHealth> {
  return { ...HEALTH };
}
/** Test-only reset. Not exported from the public barrel; use sparingly. */
export function __resetReasoningLoggerHealthForTests(): void {
  HEALTH.writesAttempted = 0;
  HEALTH.writesSucceeded = 0;
  HEALTH.writesFailed = 0;
  HEALTH.lastSuccessAt = null;
  HEALTH.lastErrorAt = null;
  HEALTH.lastErrorClass = null;
  HEALTH.lastErrorMessage = null;
}

/** Possible verdicts the paper-trade pipeline emits for a signal.
 *
 * Two families:
 *   - `EMITTED` / `PRE_EMISSION_REJECTED` are **upstream** events written
 *     by the signal-generation orchestrator (P14b). They answer "why did
 *     this signal appear?" and "why didn't this candidate appear?".
 *   - All others are **downstream** events written by the paper-trade
 *     decision boundary (P14). They answer what the trader did with the
 *     signal once it landed.
 *
 * Tier-demotion reasons (HTF_CONFLICT, RS_CONFLICT, LOW_WINRATE, ...) live
 * inside the EMITTED row's `snapshot.tags` rather than as a separate
 * decision value, so demoted signals are not double-counted in histograms.
 */
export type FnoReasoningDecision =
  | "EMITTED"
  | "PRE_EMISSION_REJECTED"
  | "OPENED"
  | "SKIPPED"
  | "MISSED_WINDOW"
  | "CLOSED_STOPPED"
  | "CLOSED_TARGET1"
  | "CLOSED_TARGET2"
  | "CLOSED_EXPIRED"
  | "CLOSED_MANUAL"
  | "CLOSED_TIME_EXIT_1520"
  | "CLOSED_TIME_EXIT_1430_EXPIRY";

/**
 * Shape accepted by `logFnoReasoning`. Every field except `decision`,
 * `signalDate`, and `indexSymbol` is optional — the writer fills in
 * what the caller knows at the decision point and leaves the rest NULL.
 *
 * `snapshot` is the forward-compat catch-all. Put gate-by-gate flags,
 * EMA stack, VWAP/VP relation, OI confluence inputs, etc. there
 * without requiring a schema migration to capture them.
 */
export interface FnoReasoningPayload {
  decision: FnoReasoningDecision;
  signalDate: string;
  indexSymbol: string;

  capturedAt?: Date;
  indexName?: string | null;
  setupKey?: string | null;
  direction?: "BULLISH" | "BEARISH" | string | null;
  optionType?: "CE" | "PE" | string | null;

  tier?: string | null;
  reasonCode?: string | null;

  /**
   * P15b — deterministic correlation ID. Operator-supplied is optional;
   * when omitted `buildReasoningRow` auto-derives it from the 6-tuple
   * (signalDate, indexSymbol, setupKey, direction, optionType,
   * selectedStrike) via `computeSignalFingerprint`. Stays null when any
   * of those six fields are missing (e.g. PRE_EMISSION_REJECTED rows
   * without a leg). NEVER carries any token, secret, session value, or
   * user-supplied free text.
   */
  signalFingerprint?: string | null;

  confidence?: number | null;
  confluenceScore?: number | null;
  regime?: string | null;
  vix?: number | null;
  ivr?: number | null;
  ivp?: number | null;

  spot?: number | null;
  spotEntry?: number | null;
  spotStop?: number | null;
  spotTarget1?: number | null;
  spotTarget2?: number | null;

  selectedStrike?: number | null;
  optionEntry?: number | null;
  optionStop?: number | null;
  optionTarget1?: number | null;
  optionTarget2?: number | null;
  optionSpreadPct?: number | null;
  optionOi?: number | null;
  optionLtp?: number | null;
  optionExit?: number | null;
  realizedPnl?: number | null;

  lifecycleStatus?: string | null;
  exitReason?: string | null;
  dataQuality?: string | null;

  maxLossPct?: number | null;
  lots?: number | null;
  lotSize?: number | null;

  snapshot?: Record<string, unknown> | null;
  note?: string | null;

  /* ─── Stage 2 · v2 columns (2026-07-16) ────────────────────────────
   *
   * All 9 fields are optional and NULL by default. They are only
   * populated when `isReasoningWriterV2Enabled()` is true (env flag
   * `REASONING_WRITER_V2_ENABLED=1`). With the flag OFF, `buildReasoningRow`
   * writes byte-identically to the pre-Stage-2 behaviour: the new columns
   * remain NULL on every row. With the flag ON, the 9 required fields
   * (all except `valuesTestedJson` and `thresholdJson` which are
   * optional per gate) MUST be populated by the caller — the writer
   * boundary emits `logger.warn` when a v2-enabled call lacks a required
   * field so the caller can be fixed. Fail-loud, not fail-silent.
   */
  gateName?: string | null;
  verdict?: import("./fnoCanonicalTaxonomy").Verdict | null;
  stage?: import("./fnoCanonicalTaxonomy").Stage | null;
  valuesTestedJson?: Record<string, unknown> | null;
  thresholdJson?: Record<string, unknown> | null;
  configVersion?: string | null;
  tradeClass?: import("./fnoCanonicalTaxonomy").TradeClass | null;
  canonicalDecision?: import("./fnoCanonicalTaxonomy").CanonicalDecision | null;
  canonicalReason?: import("./fnoCanonicalTaxonomy").CanonicalReason | null;
}

/** Numeric -> drizzle string with NaN/Inf guarding. */
function numOrNull(n: number | null | undefined, scale = 4): string | null {
  if (n == null) return null;
  if (!Number.isFinite(n)) return null;
  return n.toFixed(scale);
}

/** Integer-or-null with NaN/Inf guarding. */
function intOrNull(n: number | null | undefined): number | null {
  if (n == null) return null;
  if (!Number.isFinite(n)) return null;
  return Math.round(n);
}

/* ─── snapshot sanitiser ────────────────────────────────────────────────
 * Defence-in-depth for the JSONB catch-all. Current call sites pass NO
 * snapshot, so this is purely preventive: if a future caller ever
 * forwards a header/cookie/session object by mistake, the sanitiser
 * drops anything whose key matches a credential pattern AND caps the
 * total serialised payload so a runaway object cannot bloat the table.
 * Both rules are conservative — we'd rather drop a legitimate field
 * than persist a leaked secret. */
const SECRET_KEY_RE =
  /(token|secret|password|passwd|cookie|session|auth|bearer|api[_-]?key|access[_-]?key)/i;
const MAX_SNAPSHOT_BYTES = 16 * 1024; // 16 KB serialised — generous for gate/feature flags

function sanitiseSnapshot(
  raw: Record<string, unknown> | null | undefined,
): Record<string, unknown> | null {
  if (raw == null || typeof raw !== "object") return null;
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(raw)) {
    if (SECRET_KEY_RE.test(k)) continue; // drop credential-shaped keys
    out[k] = v;
  }
  // Cap serialised size — Postgres jsonb can hold much more but we don't
  // want diagnostics to grow without bound. Stringify failures (e.g.
  // circular refs) collapse the whole snapshot to null rather than throw.
  try {
    const s = JSON.stringify(out);
    if (s.length > MAX_SNAPSHOT_BYTES) {
      return { __truncated: true, __bytes: s.length };
    }
  } catch {
    return null;
  }
  return out;
}

/* ─── P15b — deterministic signal fingerprint ───────────────────────────
 *
 * Why: P15 analytics could only proxy a "T1→stop reversal" because rows
 * carried no correlation key. P15b adds a SHA-256(hex)[:16] over the
 * 6 fields that uniquely identify a trade lifecycle so EMITTED → OPENED
 * → CLOSED_* rows for the same signal/trade share an exact key.
 *
 * Inputs are deliberately RESTRICTED to fields already persisted on the
 * row itself (signal_date / index_symbol / setup_key / direction /
 * option_type / selected_strike). NO timestamp, NO token, NO secret,
 * NO session, NO premium, NO PII — the hash input set is whitelisted
 * here in source and asserted in tests.
 *
 * Diagnostics-only: NEVER consumed by signal generation, gates, sizing,
 * execution, scheduler, scanner, swing, paper-equity, Kite, combo, or
 * any ingestion path. */
const FINGERPRINT_PARTS = [
  "signalDate", "indexSymbol", "setupKey", "direction", "optionType", "selectedStrike",
] as const;

export interface FingerprintParts {
  signalDate?: string | null;
  indexSymbol?: string | null;
  setupKey?: string | null;
  direction?: string | null;
  optionType?: string | null;
  selectedStrike?: number | null;
}

export function computeSignalFingerprint(p: FingerprintParts): string | null {
  if (!p.signalDate || !p.indexSymbol) return null;
  if (!p.setupKey || !p.direction || !p.optionType) return null;
  if (p.selectedStrike == null || !Number.isFinite(p.selectedStrike)) return null;
  // Normalise: lowercase identity-ish fields, fixed-decimal strike, pipe-delimited
  // canonical key. Pipe is the separator because no field is allowed to contain it
  // (all six are bounded varchars or a number).
  const key = [
    String(p.signalDate).trim(),
    String(p.indexSymbol).trim().toUpperCase(),
    String(p.setupKey).trim().toUpperCase(),
    String(p.direction).trim().toUpperCase(),
    String(p.optionType).trim().toUpperCase(),
    Number(p.selectedStrike).toFixed(2),
  ].join("|");
  // Lazy crypto import to keep this module side-effect-free at import time.
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { createHash } = require("node:crypto") as typeof import("node:crypto");
  return createHash("sha256").update(key).digest("hex").slice(0, 16);
}

/** Test-visible whitelist of allowed fingerprint parts. */
export const FINGERPRINT_INPUT_FIELDS: ReadonlyArray<string> = FINGERPRINT_PARTS;

/** String trim/cap helper (avoid blowing varchar limits silently). */
function strOrNull(s: string | null | undefined, max: number): string | null {
  if (s == null) return null;
  const t = String(s).trim();
  if (t.length === 0) return null;
  return t.length > max ? t.slice(0, max) : t;
}

/**
 * Pure helper exposed for tests — converts the public payload to the
 * exact row shape we hand to drizzle. No DB I/O.
 */
export function buildReasoningRow(p: FnoReasoningPayload): NewFnoSignalReasoningRow {
  const v2 = isReasoningWriterV2Enabled();
  return {
    capturedAt: p.capturedAt ?? new Date(),
    signalDate: p.signalDate,
    indexSymbol: strOrNull(p.indexSymbol, 32) ?? p.indexSymbol,
    indexName: strOrNull(p.indexName, 64),
    setupKey: strOrNull(p.setupKey, 64),
    direction: strOrNull(p.direction ?? null, 16),
    optionType: strOrNull(p.optionType ?? null, 4),
    tier: strOrNull(p.tier, 16),
    decision: strOrNull(p.decision, 32) ?? p.decision,
    reasonCode: strOrNull(p.reasonCode, 64),
    // P15b: trust operator-supplied value if shape-valid; otherwise auto-derive
    // from the 6-tuple in scope. Stays null when fields are missing (e.g.
    // PRE_EMISSION_REJECTED / SKIPPED rows without a leg → proxy fallback).
    signalFingerprint:
      (typeof p.signalFingerprint === "string" && /^[0-9a-f]{16}$/.test(p.signalFingerprint)
        ? p.signalFingerprint
        : computeSignalFingerprint({
            signalDate: p.signalDate,
            indexSymbol: p.indexSymbol,
            setupKey: p.setupKey ?? null,
            direction: p.direction ?? null,
            optionType: p.optionType ?? null,
            selectedStrike: p.selectedStrike ?? null,
          })),
    confidence: intOrNull(p.confidence),
    confluenceScore: numOrNull(p.confluenceScore, 2),
    regime: strOrNull(p.regime, 24),
    vix: numOrNull(p.vix, 2),
    ivr: numOrNull(p.ivr, 2),
    ivp: numOrNull(p.ivp, 2),
    spot: numOrNull(p.spot, 2),
    spotEntry: numOrNull(p.spotEntry, 2),
    spotStop: numOrNull(p.spotStop, 2),
    spotTarget1: numOrNull(p.spotTarget1, 2),
    spotTarget2: numOrNull(p.spotTarget2, 2),
    selectedStrike: numOrNull(p.selectedStrike, 2),
    optionEntry: numOrNull(p.optionEntry, 4),
    optionStop: numOrNull(p.optionStop, 4),
    optionTarget1: numOrNull(p.optionTarget1, 4),
    optionTarget2: numOrNull(p.optionTarget2, 4),
    optionSpreadPct: numOrNull(p.optionSpreadPct, 4),
    optionOi: intOrNull(p.optionOi),
    optionLtp: numOrNull(p.optionLtp, 4),
    optionExit: numOrNull(p.optionExit, 4),
    realizedPnl: numOrNull(p.realizedPnl, 2),
    lifecycleStatus: strOrNull(p.lifecycleStatus, 24),
    exitReason: strOrNull(p.exitReason, 32),
    dataQuality: strOrNull(p.dataQuality, 32),
    maxLossPct: numOrNull(p.maxLossPct, 4),
    lots: intOrNull(p.lots),
    lotSize: intOrNull(p.lotSize),
    snapshot: sanitiseSnapshot(p.snapshot ?? null),
    note: p.note ?? null,

    /* ─── Stage 2 · v2 columns ─────────────────────────────────────────
     * When the flag is OFF, all 9 columns stay NULL — the row shape
     * is byte-identical to the pre-Stage-2 behaviour. When the flag is
     * ON, the writer stamps whatever the caller supplied (and NULL for
     * anything omitted — the fail-loud "required" check for these
     * fields lives at the call site, not the writer, so the writer
     * itself never blocks a diagnostic path). */
    gateName: v2 ? strOrNull(p.gateName ?? null, 64) : null,
    verdict: v2 ? strOrNull(p.verdict ?? null, 16) : null,
    stage: v2 ? strOrNull(p.stage ?? null, 24) : null,
    valuesTestedJson: v2 ? (p.valuesTestedJson ?? null) : null,
    thresholdJson: v2 ? (p.thresholdJson ?? null) : null,
    // configVersion falls back to `fno-config-legacy-v0` per §16 bootstrap
    // rule: writers that predate the config registry document the gap
    // without failing writes.
    configVersion: v2
      ? strOrNull(p.configVersion ?? "fno-config-legacy-v0", 32)
      : null,
    tradeClass: v2 ? strOrNull(p.tradeClass ?? null, 16) : null,
    canonicalDecision: v2 ? strOrNull(p.canonicalDecision ?? null, 24) : null,
    canonicalReason: v2 ? strOrNull(p.canonicalReason ?? null, 48) : null,
  };
}

/**
 * Append one reasoning row. **Never throws.** Safe to call from any
 * decision point in the F&O pipeline — including inside transactions
 * (this opens its own connection via the singleton `db`), inside
 * setInterval ticks, and inside synchronous helpers (via `void`).
 *
 * On failure, emits one `logger.warn` so the operator sees substrate
 * outages explicitly without spamming the request log.
 */
/**
 * Writer-boundary guard (2026-07-16, P0.4 Step 2 quarantine).
 *
 * Refuses to write into the reasoning table when running under a test
 * runner (vitest / NODE_ENV=test) unless an explicit
 * `ALLOW_TEST_DB_WRITES=1` override is present. This is the systemic
 * fix for the class of defect that leaked 18 `TREND_CONTINUATION` stub
 * rows into prod diagnostics (fnoObservability.test.ts calling
 * `logFnoReasoning` against a live DATABASE_URL on every test run).
 *
 * The guard is intentionally at the writer boundary rather than the
 * caller — one guarded seam protects every current and future test
 * file that happens to import the logger. Failure mode is fail-loud:
 * an Error is thrown here and caught by the surrounding try/catch,
 * which increments `writesFailed` and stamps `lastErrorClass` so the
 * next test-suite-writer sees the guard in the health surface
 * immediately.
 *
 * ALLOW_TEST_DB_WRITES=1 exists for exactly one intended use: purpose-
 * built integration tests running against a disposable test DB. It
 * must NEVER be set in dev/CI envs that carry the prod DATABASE_URL.
 */
function assertNotProdDbInTest(): void {
  const inTestEnv =
    process.env.VITEST === "true" || process.env.NODE_ENV === "test";
  const overrideAllowed = process.env.ALLOW_TEST_DB_WRITES === "1";
  if (inTestEnv && !overrideAllowed) {
    throw new Error(
      "REASONING_WRITER_TEST_GUARD: refused to write from a test process (VITEST/NODE_ENV=test) without ALLOW_TEST_DB_WRITES=1. Mock the db module or run against a disposable test DB.",
    );
  }
}

export async function logFnoReasoning(payload: FnoReasoningPayload): Promise<boolean> {
  HEALTH.writesAttempted += 1;
  try {
    assertNotProdDbInTest();
    const row = buildReasoningRow(payload);
    await db.insert(fnoSignalReasoningTable).values(row);
    HEALTH.writesSucceeded += 1;
    HEALTH.lastSuccessAt = new Date().toISOString();
    return true;
  } catch (err) {
    // Swallowed — diagnostics MUST NOT influence trading. One WARN per
    // failure keeps the issue visible in logs without crashing the
    // pipeline. We intentionally do NOT re-throw, retry, or back off.
    HEALTH.writesFailed += 1;
    HEALTH.lastErrorAt = new Date().toISOString();
    // Robust extraction — non-Error throwables (strings, plain objects)
    // must not crash this catch arm. Compute message ONCE and reuse.
    const errIsError = err instanceof Error;
    const errMessage = errIsError ? err.message : String(err);
    HEALTH.lastErrorClass = errIsError ? err.constructor.name : typeof err;
    // Truncate message defensively — never persist secrets/tokens; also
    // bound the visible length surfaced by the health endpoint.
    HEALTH.lastErrorMessage = errMessage.slice(0, 200);
    logger.warn(
      {
        err: errMessage,
        decision: payload.decision,
        indexSymbol: payload.indexSymbol,
        setupKey: payload.setupKey,
      },
      "fno_signal_reasoning write failed (diagnostics-only; trading unaffected)",
    );
    return false;
  }
}

/* ─────────────────── Upstream emission helpers (P14b) ───────────────────
 *
 * The orchestrator (`getOptionSignals`) calls these AT THE VERY END of a
 * cycle to record:
 *
 *   - one `EMITTED` row per signal that survived every gate, with the
 *     full driver/tag/regime/IVR/IVP/EMA/VWAP context lifted out of the
 *     OptionSignal verbatim, and demotion tags surfaced in `snapshot.tags`.
 *
 *   - one `PRE_EMISSION_REJECTED` row per `{index, reason}` pair from the
 *     orchestrator's `suppressed` diagnostic. Best-effort parses the
 *     leading `setup_name:` prefix off the reason string so histograms by
 *     setup work for both emitted and rejected populations.
 *
 * Both helpers are PURE (no I/O) and the public `logUpstreamReasoningBatch`
 * is non-throwing — a logger outage cannot disturb the signal pipeline.
 *
 * No live signal field is mutated and no decision the engine has already
 * taken is re-derived here. The orchestrator's `suppressed` array, which
 * was already populated for the UI banner, is the sole source of truth
 * for rejection reasons.
 */

/** Loose shape we accept for upstream emission — kept narrow on purpose so
 *  a stray `OptionSignal` field rename doesn't break the build. We only
 *  touch documented public fields. */
export interface UpstreamSignalShape {
  index: string;
  indexName?: string;
  setupKey?: string;
  setupName?: string;
  bias: string;
  tier?: string;
  tradeClass?: string;
  confidence: number;
  confluenceScore?: number;
  regime?: string;
  spot?: number;
  vwap?: number;
  ema9?: number;
  ema20?: number;
  ema21?: number;
  ema50?: number;
  dailyEma50?: number;
  htfBias?: string;
  htfConflict?: boolean;
  ivRank?: number;
  ivPercentile?: number;
  dataQuality?: string;
  tags?: string[];
  drivers?: Array<{ label?: string; weight?: number; detail?: string; bullish?: boolean }>;
  leg?: { type?: string; strike?: number; entry?: number; stopLoss?: number; target1?: number; target2?: number };
}

/** Loose shape for the orchestrator's per-index suppression bundle. */
export interface UpstreamSuppressed {
  index: string;
  reasons: string[];
}

/**
 * Parse `"trend_continuation: confidence 58 < HC emission floor 65 — demoted"`
 * into `{ setupKey: "TREND_CONTINUATION", reason: "confidence 58 < ..." }`.
 *
 * The orchestrator emits suppression strings with two shapes:
 *   - `"<detector_name>: <reason>"` from inside `buildSignalsForIndex`
 *   - `"<SETUP_KEY>: <reason>"`     from the bundle-level drop aggregators
 *
 * Both encode the setup in the leading chunk, so a single split works.
 */
export function parseSuppressionReason(raw: string): {
  setupKey: string | null;
  reason: string;
} {
  if (typeof raw !== "string") return { setupKey: null, reason: "" };
  const t = raw.trim();
  if (!t) return { setupKey: null, reason: "" };
  const i = t.indexOf(":");
  if (i <= 0) return { setupKey: null, reason: t };
  const lead = t.slice(0, i).trim();
  const rest = t.slice(i + 1).trim();
  if (!lead) return { setupKey: null, reason: rest };
  return { setupKey: lead.toUpperCase().replace(/\s+/g, "_"), reason: rest };
}

/** Map a free-text suppression reason to a stable `reason_code` enum for
 *  histograms. Unknown reasons collapse to `OTHER` so the bucket cardinality
 *  stays manageable across cycles. */
export function classifySuppressionReason(reason: string): string {
  const r = reason.toLowerCase();
  if (r.includes("market_closed") || r.includes("market closed")) return "MARKET_CLOSED";
  if (r.includes("partial_indicators") || r.includes("partial indicators")) return "PARTIAL_INDICATORS";
  if (r.includes("opening-noise") || r.includes("opening_noise")) return "OPENING_NOISE";
  if (r.includes("late-session vwap-reclaim") || r.includes("vwap-reclaim gate")) return "VWAP_RECLAIM_LATE";
  if (r.includes("late-session entry") || r.includes("late_session_entry")) return "LATE_SESSION_ENTRY";
  // OI buckets must be checked BEFORE the generic "hc emission floor" rule —
  // the orchestrator's OI-post-floor message literally reads
  // "post-OI confidence X < HC emission floor Y — demoted (OI conflict ...)"
  // and the semantic root cause is the OI conflict, not the floor itself.
  if (r.includes("oi hard-veto") || r.includes("oi hard veto")) return "OI_VETO";
  if (r.includes("post-oi confidence") || r.includes("oi conflict")) return "OI_CONFLICT";
  if (r.includes("hc emission floor")) return "HC_FLOOR";
  if (r.includes("post-clamp rr")) return "POST_CLAMP_RR";
  if (r.includes("conditions not met")) return "CONDITIONS_NOT_MET";
  if (r.includes("circuit-breaker") || r.includes("circuit breaker")) return "CIRCUIT_BREAKER";
  if (r.includes("vol_regime") || r.includes("vol regime")) return "VOL_REGIME";
  if (r.includes("flip") || r.includes("bias-flip") || r.includes("bias flip")) return "BIAS_FLIP";
  if (r.includes("correlation") || r.includes("redundant")) return "CORRELATION_CAP";
  if (r.includes("global suppression")) return "GLOBAL_SUPPRESSION";
  if (r.includes("no_bars") || r.includes("no bars")) return "NO_BARS";
  if (r === "error" || r.startsWith("error")) return "DETECTOR_ERROR";
  if (r.includes("no_live_kite_intraday") || r.includes("no live kite intraday")) return "NO_LIVE_KITE_INTRADAY";
  if (r.includes("daily_history_warmup_kite") || r.includes("daily history warmup")) return "DAILY_HISTORY_WARMUP";
  if (r.includes("daily_history_unavailable_kite") || r.includes("daily history unavailable")) return "DAILY_HISTORY_UNAVAILABLE";
  return "OTHER";
}

/**
 * Build one EMITTED row from a live OptionSignal. Pure — no I/O. Captures
 * every field the upstream reasoning spec asks for; missing-data fields
 * (e.g. IVR null at emission time) are flagged in `snapshot.missing`.
 */
export function buildEmittedRow(
  s: UpstreamSignalShape,
  signalDate: string,
  vix: number | null,
): FnoReasoningPayload {
  const tags = Array.isArray(s.tags) ? s.tags : [];
  const drivers = Array.isArray(s.drivers)
    ? s.drivers.slice(0, 24).map(d => ({
        label: d.label,
        weight: d.weight,
        detail: d.detail,
        bullish: d.bullish,
      }))
    : [];
  const missing: string[] = [];
  if (s.ivRank == null) missing.push("ivRank");
  if (s.ivPercentile == null) missing.push("ivPercentile");
  if (vix == null) missing.push("vix");
  if (s.vwap == null) missing.push("vwap");
  if (s.ema50 == null) missing.push("ema50");
  // Tag-derived demotion reasons (HTF/RS/LOW_WINRATE/OPENING_NOISE/etc.) —
  // surfaced as a separate snapshot field so a downstream query can ask
  // "how many EMITTED rows carried at least one demotion tag?" without
  // splitting tag strings.
  const DEMOTION_TAGS = new Set([
    "HTF_CONFLICT", "HTF1H_CONFLICT", "RS_CONFLICT", "LOW_WINRATE",
    "OPENING_NOISE", "CLOSING_NOISE", "EXPIRY_DAY", "OI_ATM_CONFLICT",
    "VOL_CLAMPED_STOP", "COUNTER_TREND", "RR_LOW",
    // 2026-06-09 hygiene vetoes — surfaced as first-class demotion tags so
    // they flow into the byDemotionTag histogram and the blocked-signals
    // review without splitting tag strings.
    "RECOVERY_MODE_VETO", "CHASE_RISK_VETO",
  ]);
  const demotionTags = tags.filter(t => DEMOTION_TAGS.has(t));
  const emaStack = {
    ema9: s.ema9 ?? null,
    ema20: s.ema20 ?? null,
    ema21: s.ema21 ?? null,
    ema50: s.ema50 ?? null,
    dailyEma50: s.dailyEma50 ?? null,
  };
  const vwapRel = s.vwap != null && s.spot != null
    ? (s.spot > s.vwap ? "ABOVE" : s.spot < s.vwap ? "BELOW" : "AT")
    : null;

  // Stage 2 · Site D canonical shadow (P0.4 Step 2 · 2026-07-16).
  // Site D writes legacy reason_code='DEMOTED' when demotionTags is
  // non-empty — that's the exact legacy-writer bug the taxonomy helper
  // throws on. Per session ruling: byte-identical legacy line stays,
  // canonical shadow bypasses the helper's throw with a documented
  // override that maps the primary demotion tag to its canonical bucket
  // rather than dropping the information on the floor as generic
  // UNMAPPED. Writer-fix ticket for the underlying reason_code echo:
  // TODO-P0.4-writer-fix — remove the legacy `reason_code = 'DEMOTED'`
  // line once every downstream consumer has migrated to reading
  // `canonical_decision = 'DEMOTED'` instead.
  const isDemoted = demotionTags.length > 0;
  const canonicalDecision: CanonicalDecision | null = isDemoted
    ? "DEMOTED"
    : "EXECUTABLE";
  const canonicalReason: CanonicalReason | null = isDemoted
    ? mapDemotionTagsToCanonicalReason(demotionTags)
    : "UNMAPPED"; // EMITTED-EXECUTABLE emissions carry no reason bucket
  // TradeClass promoted from snapshot to first-class column.
  const rawTradeClass = (s.tradeClass ?? "").toUpperCase();
  const tradeClass: TradeClass | null =
    rawTradeClass === "TRADEABLE" ||
    rawTradeClass === "WATCHLIST" ||
    rawTradeClass === "INFO_ONLY" ||
    rawTradeClass === "DIAG"
      ? (rawTradeClass as TradeClass)
      : null;

  return {
    decision: "EMITTED",
    signalDate,
    indexSymbol: s.index,
    indexName: s.indexName ?? null,
    setupKey: s.setupKey ?? null,
    direction: s.bias ?? null,
    optionType: s.leg?.type === "CALL" ? "CE" : s.leg?.type === "PUT" ? "PE" : null,
    tier: s.tier ?? null,
    reasonCode: isDemoted ? "DEMOTED" : "EMITTED",
    confidence: s.confidence ?? null,
    confluenceScore: s.confluenceScore ?? null,
    regime: s.regime ?? null,
    vix,
    ivr: s.ivRank ?? null,
    ivp: s.ivPercentile ?? null,
    spot: s.spot ?? null,
    spotEntry: s.leg?.entry ?? null,
    spotStop: s.leg?.stopLoss ?? null,
    spotTarget1: s.leg?.target1 ?? null,
    spotTarget2: s.leg?.target2 ?? null,
    selectedStrike: s.leg?.strike ?? null,
    dataQuality: s.dataQuality ?? null,
    snapshot: {
      setupName: s.setupName ?? null,
      tags,
      demotionTags,
      // 2026-06-09 hygiene: persist the explicit trade-class so the
      // blocked-signals review can answer "did BASELINE only ever appear
      // as INFO_ONLY?" without re-deriving from tier.
      tradeClass: s.tradeClass ?? null,
      drivers,
      emaStack,
      vwapRel,
      htfBias: s.htfBias ?? null,
      htfConflict: s.htfConflict ?? null,
      missing,
    },
    // Stage 2 canonical shadow — populated only when v2 flag is ON
    // (buildReasoningRow enforces the NULL guard on flag OFF).
    gateName: "EMISSION",
    verdict: isDemoted ? "DEMOTE" : "PASS",
    stage: "EMISSION",
    tradeClass,
    canonicalDecision,
    canonicalReason,
  };
}

/** Build PRE_EMISSION_REJECTED rows from the orchestrator `suppressed` array. */
export function buildPreEmissionRejectedRows(
  suppressed: ReadonlyArray<UpstreamSuppressed>,
  signalDate: string,
): FnoReasoningPayload[] {
  const out: FnoReasoningPayload[] = [];
  for (const bucket of suppressed) {
    if (!bucket || typeof bucket.index !== "string") continue;
    const reasons = Array.isArray(bucket.reasons) ? bucket.reasons : [];
    for (const raw of reasons) {
      const { setupKey, reason } = parseSuppressionReason(String(raw));
      const reasonCode = classifySuppressionReason(reason);
      // Stage 2 canonical shadow — derive from (decision, reason_code).
      // The helper handles the NO_LIVE_KITE_INTRADAY → DATA_BLOCKED
      // reason-based override so data failures don't share a bucket
      // with strategy rejections. OTHER as reason_code will throw at
      // the helper — that's the intended behaviour (OTHER banned in
      // new writes). We swallow the throw here and stamp UNMAPPED so
      // one bad row doesn't poison the batch; the writer's warn path
      // still records the anomaly.
      let canonicalDecision: CanonicalDecision;
      let canonicalReason: CanonicalReason;
      try {
        const canon = mapDecisionToCanonical({
          decision: "PRE_EMISSION_REJECTED",
          reasonCode,
        });
        canonicalDecision = canon.canonicalDecision;
        canonicalReason = canon.canonicalReason;
      } catch {
        // OTHER-ban or legacy-writer-bug throws land here. The row
        // still writes with UNMAPPED so the funnel count is preserved;
        // downstream can filter on `canonical_reason='UNMAPPED'` to
        // see how much OTHER traffic the classifier saw.
        canonicalDecision = "REJECTED";
        canonicalReason = "UNMAPPED";
      }
      out.push({
        decision: "PRE_EMISSION_REJECTED",
        signalDate,
        indexSymbol: bucket.index,
        setupKey,
        reasonCode,
        note: reason.slice(0, 240),
        snapshot: { rawReason: String(raw).slice(0, 480) },
        // Stage 2 v2 canonical shadow (NULL when flag OFF via row builder).
        gateName: "PRE_EMISSION_GATE",
        verdict: canonicalDecision === "DATA_BLOCKED" ? "NOT_EVALUATED" : "FAIL",
        stage: "PRE_EMISSION",
        tradeClass: null, // pre-emission rejections have no trade class yet
        canonicalDecision,
        canonicalReason,
      });
    }
  }
  return out;
}

/**
 * Build the full set of upstream rows for one `getOptionSignals` cycle.
 * Pure; tests call this directly. Empty inputs produce an empty array.
 */
export function buildUpstreamReasoningRows(args: {
  signals: ReadonlyArray<UpstreamSignalShape>;
  suppressed: ReadonlyArray<UpstreamSuppressed>;
  signalDate: string;
  vix?: number | null;
}): FnoReasoningPayload[] {
  const vix = args.vix ?? null;
  const rows: FnoReasoningPayload[] = [];
  for (const s of args.signals) {
    try {
      rows.push(buildEmittedRow(s, args.signalDate, vix));
    } catch {
      // Skip individual signal whose shape blew up; never throw upward.
    }
  }
  rows.push(...buildPreEmissionRejectedRows(args.suppressed, args.signalDate));
  return rows;
}

/* ─────────────── Upstream once-per-transition dedupe (2026-06-05) ───────────
 *
 * The orchestrator calls `logUpstreamReasoningBatch` on every ~30s poll. The
 * old contract wrote an EMITTED / PRE_EMISSION_REJECTED row EVERY tick, so a
 * single signal in one unchanged state produced ~88 duplicate rows (worst case
 * 307×), which broke every count and win-rate derived from the table.
 *
 * Fix (per `signal_logging_fix_spec.md` §2): write a row ONLY when a signal's
 * (identity, state) changes. State = (decision, reason_code) so a genuine
 * reason-change is preserved but the same reason repeating is collapsed.
 *
 * Scope: this gate governs ONLY the upstream batch (EMITTED /
 * PRE_EMISSION_REJECTED). The downstream OPENED / SKIPPED / CLOSED_* writers
 * are already deduped by their own once-per-day / once-per-lifecycle contracts
 * and are left untouched.
 *
 * Pure-testable: `reasoningDedupeIdentity`, `reasoningStateKey`, and
 * `selectUpstreamRowsToWrite` have no I/O. Boot hydration seeds the in-memory
 * map from today's already-written upstream rows so a mid-day restart does not
 * re-write existing transitions. The whole gate fails OPEN — any hydration
 * error just means we might write a few duplicate rows once, never that we
 * block a write or throw. */

/** Loose shape covering both the write payload and a persisted row, enough to
 *  derive the dedupe identity. */
export interface DedupeIdentityInput {
  signalFingerprint?: string | null;
  signalDate?: string | null;
  indexSymbol?: string | null;
  setupKey?: string | null;
  direction?: string | null;
  optionType?: string | null;
  selectedStrike?: number | string | null;
}

/**
 * Stable dedupe identity for a reasoning event: the SHA-256 fingerprint when
 * available (computed from the 6-tuple, or trusted if pre-supplied), else a
 * `px:` proxy over the stable identity fields for leg-less rows (e.g.
 * PRE_EMISSION_REJECTED). Pure.
 */
export function reasoningDedupeIdentity(p: DedupeIdentityInput): string {
  const supplied =
    typeof p.signalFingerprint === "string" && /^[0-9a-f]{16}$/.test(p.signalFingerprint)
      ? p.signalFingerprint
      : null;
  const strikeNum = p.selectedStrike == null ? null : Number(p.selectedStrike);
  const fp =
    supplied ??
    computeSignalFingerprint({
      signalDate: p.signalDate ?? null,
      indexSymbol: p.indexSymbol ?? null,
      setupKey: p.setupKey ?? null,
      direction: p.direction ?? null,
      optionType: p.optionType ?? null,
      selectedStrike: strikeNum != null && Number.isFinite(strikeNum) ? strikeNum : null,
    });
  if (fp) return `fp:${fp}`;
  return (
    "px:" +
    [p.signalDate, p.indexSymbol, p.setupKey, p.direction]
      .map((x) => String(x ?? "").trim().toUpperCase())
      .join("|")
  );
}

/** Dedupe state key = (decision, reason_code), normalised. Pure. */
export function reasoningStateKey(p: { decision: string; reasonCode?: string | null }): string {
  return `${String(p.decision).trim().toUpperCase()}|${String(p.reasonCode ?? "").trim().toUpperCase()}`;
}

/**
 * Given candidate upstream rows and the per-identity last-logged-state map,
 * return only the rows whose (identity, state) differs from the last
 * SUCCESSFULLY-written state, collapsing duplicates WITHIN the batch too.
 *
 * PURE — it does NOT mutate `lastState`. The caller commits each identity's
 * new state into the map only after the write actually succeeds
 * (`commitUpstreamDedupeState`), so a transient DB failure leaves the state
 * un-advanced and the transition is retried on the next cycle. This is the
 * fail-OPEN contract: we would rather write one duplicate row than silently
 * drop a transition from the diagnostics substrate.
 */
export function selectUpstreamRowsToWrite(
  rows: ReadonlyArray<FnoReasoningPayload>,
  lastState: ReadonlyMap<string, string>,
): FnoReasoningPayload[] {
  const out: FnoReasoningPayload[] = [];
  const seenInBatch = new Set<string>();
  for (const r of rows) {
    const id = reasoningDedupeIdentity(r);
    const sk = reasoningStateKey(r);
    if (lastState.get(id) === sk) continue; // unchanged since last write — the 88× killer
    const batchKey = `${id}\u0000${sk}`;
    if (seenInBatch.has(batchKey)) continue; // collapse exact dups within the batch
    seenInBatch.add(batchKey);
    out.push(r);
  }
  return out;
}

/** Record a successfully-written row's (identity → state) into the dedupe map.
 *  Called by the writer ONLY after the insert succeeds. Pure aside from the
 *  explicit, intended map mutation. */
export function commitUpstreamDedupeState(
  row: FnoReasoningPayload,
  lastState: Map<string, string>,
): void {
  lastState.set(reasoningDedupeIdentity(row), reasoningStateKey(row));
}

const UPSTREAM_DEDUPE_DECISIONS = new Set<string>(["EMITTED", "PRE_EMISSION_REJECTED"]);

/* Process-local dedupe state for the upstream batch. Reset on restart; that is
 * the desired semantic — hydration re-seeds it from the DB for the current day
 * so a restart doesn't re-duplicate already-written transitions. */
const upstreamLastState = new Map<string, string>();
let upstreamHydratedForDate: string | null = null;

/** Test-only reset of the upstream dedupe state. */
export function __resetUpstreamReasoningDedupeForTests(): void {
  upstreamLastState.clear();
  upstreamHydratedForDate = null;
}

/**
 * Seed `upstreamLastState` from the upstream rows already written for
 * `signalDate`, latest-state-per-identity wins. Runs once per date (a new
 * trading day clears yesterday's keys). Fails OPEN — on any error we leave the
 * map as-is and mark the date hydrated so we don't spin retrying.
 */
async function hydrateUpstreamDedupe(signalDate: string): Promise<void> {
  if (upstreamHydratedForDate === signalDate) return;
  upstreamLastState.clear();
  try {
    const rows = await db
      .select({
        signalFingerprint: fnoSignalReasoningTable.signalFingerprint,
        signalDate: fnoSignalReasoningTable.signalDate,
        indexSymbol: fnoSignalReasoningTable.indexSymbol,
        setupKey: fnoSignalReasoningTable.setupKey,
        direction: fnoSignalReasoningTable.direction,
        optionType: fnoSignalReasoningTable.optionType,
        selectedStrike: fnoSignalReasoningTable.selectedStrike,
        decision: fnoSignalReasoningTable.decision,
        reasonCode: fnoSignalReasoningTable.reasonCode,
      })
      .from(fnoSignalReasoningTable)
      .where(eq(fnoSignalReasoningTable.signalDate, signalDate))
      .orderBy(asc(fnoSignalReasoningTable.capturedAt), asc(fnoSignalReasoningTable.id));
    for (const r of rows) {
      // Only the decisions this gate governs — downstream rows have their own
      // dedupe and must not pollute the upstream identity→state map.
      if (!UPSTREAM_DEDUPE_DECISIONS.has(String(r.decision).trim().toUpperCase())) continue;
      upstreamLastState.set(
        reasoningDedupeIdentity(r),
        reasoningStateKey({ decision: r.decision, reasonCode: r.reasonCode }),
      );
    }
  } catch (err) {
    logger.warn(
      { err: (err as Error).message, signalDate },
      "fno_signal_reasoning upstream dedupe hydration failed (diagnostics-only; fail-open)",
    );
  }
  upstreamHydratedForDate = signalDate;
}

/**
 * Non-throwing batch writer used by the orchestrator hook. Each row is
 * dispatched via `logFnoReasoning` (already non-throwing) so a single
 * bad row never poisons the batch and a DB outage emits a single WARN
 * per row without disturbing the caller.
 *
 * Once-per-transition deduped: rows whose (identity, state) is unchanged since
 * the last write are skipped (see the dedupe block above). Hydrates the dedupe
 * map from the DB once per `signalDate` so a mid-day restart doesn't re-write
 * existing transitions.
 *
 * Caller idiom: `void logUpstreamReasoningBatch({...})` — fire-and-forget.
 */
export async function logUpstreamReasoningBatch(args: {
  signals: ReadonlyArray<UpstreamSignalShape>;
  suppressed: ReadonlyArray<UpstreamSuppressed>;
  signalDate: string;
  vix?: number | null;
}): Promise<void> {
  let rows: FnoReasoningPayload[];
  try {
    rows = buildUpstreamReasoningRows(args);
  } catch (err) {
    logger.warn(
      { err: (err as Error).message },
      "fno_signal_reasoning upstream batch build failed (diagnostics-only)",
    );
    return;
  }

  // Seed dedupe state from the DB once per day so a restart doesn't re-dup.
  await hydrateUpstreamDedupe(args.signalDate);

  // Collapse to genuine transitions only — this is the fix for the ~88×
  // duplicate inflation. Selection is PURE (does not advance the map); the
  // per-identity state is committed below only after the write succeeds, so a
  // transient DB failure is retried next cycle rather than silently dropped.
  const toWrite = selectUpstreamRowsToWrite(rows, upstreamLastState);

  // Sequential await — count is small (signals + suppressed ≈ <50/cycle),
  // and we'd rather not flood the connection pool from a diagnostic path.
  for (const r of toWrite) {
    const ok = await logFnoReasoning(r);
    if (ok) commitUpstreamDedupeState(r, upstreamLastState);
  }
}

/* ─────────────────────── Query side (route helpers) ────────────────────── */

export interface ReasoningQueryFilters {
  indexSymbol?: string;
  setupKey?: string;
  direction?: string;
  tier?: string;
  decision?: string;
  reasonCode?: string;
  from?: string; // YYYY-MM-DD inclusive (signal_date)
  to?: string;   // YYYY-MM-DD inclusive
  limit?: number;
}

const MAX_LIMIT = 500;
const DEFAULT_LIMIT = 100;

/** Trims, caps, and validates the public filter shape. */
export function normaliseFilters(raw: Record<string, unknown>): ReasoningQueryFilters {
  const isValidDate = (s: unknown): s is string => {
    if (typeof s !== "string") return false;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
    const t = Date.parse(`${s}T00:00:00Z`);
    if (Number.isNaN(t)) return false;
    return new Date(t).toISOString().slice(0, 10) === s;
  };
  const pickStr = (k: string, max: number): string | undefined => {
    const v = raw[k];
    if (typeof v !== "string") return undefined;
    const t = v.trim();
    if (!t) return undefined;
    return t.length > max ? t.slice(0, max) : t;
  };
  const limitRaw = raw.limit;
  let limit = DEFAULT_LIMIT;
  if (typeof limitRaw === "string" || typeof limitRaw === "number") {
    const n = Number(limitRaw);
    if (Number.isFinite(n) && n > 0) limit = Math.min(Math.floor(n), MAX_LIMIT);
  }
  return {
    indexSymbol: pickStr("index", 32) ?? pickStr("indexSymbol", 32),
    setupKey: pickStr("setup", 64) ?? pickStr("setupKey", 64),
    direction: pickStr("direction", 16) ?? pickStr("side", 16),
    tier: pickStr("tier", 16),
    decision: pickStr("decision", 32) ?? pickStr("status", 32),
    reasonCode: pickStr("reason", 64) ?? pickStr("reasonCode", 64),
    from: isValidDate(raw.from) ? raw.from : undefined,
    to: isValidDate(raw.to) ? raw.to : undefined,
    limit,
  };
}

function whereFromFilters(f: ReasoningQueryFilters) {
  const conds = [] as ReturnType<typeof eq>[];
  if (f.indexSymbol) conds.push(eq(fnoSignalReasoningTable.indexSymbol, f.indexSymbol));
  if (f.setupKey) conds.push(eq(fnoSignalReasoningTable.setupKey, f.setupKey));
  if (f.direction) conds.push(eq(fnoSignalReasoningTable.direction, f.direction));
  if (f.tier) conds.push(eq(fnoSignalReasoningTable.tier, f.tier));
  if (f.decision) conds.push(eq(fnoSignalReasoningTable.decision, f.decision));
  if (f.reasonCode) conds.push(eq(fnoSignalReasoningTable.reasonCode, f.reasonCode));
  if (f.from) conds.push(gte(fnoSignalReasoningTable.signalDate, f.from));
  if (f.to) conds.push(lte(fnoSignalReasoningTable.signalDate, f.to));
  return conds.length === 0 ? undefined : and(...conds);
}

export interface ReasoningHistogram {
  byDecision: Array<{ key: string; count: number }>;
  byReason: Array<{ key: string; count: number }>;
  byIndex: Array<{ key: string; count: number }>;
  bySetup: Array<{ key: string; count: number }>;
  byTier: Array<{ key: string; count: number }>;
  byStopReason: Array<{ key: string; count: number }>; // setup-by-setup count of CLOSED_STOPPED rows
  total: number;
}

export interface ReasoningQueryResult {
  rows: FnoSignalReasoningRow[];
  histogram: ReasoningHistogram;
  filters: ReasoningQueryFilters;
}

/**
 * Returns the most-recent matching reasoning rows plus histograms.
 * Histograms are computed over the same filter set (NOT the whole table)
 * so the owner sees breakdowns that match what they're looking at.
 *
 * Caps at `limit` rows (default 100, max 500) to keep the response cheap.
 */
export async function queryReasoning(
  filters: ReasoningQueryFilters,
): Promise<ReasoningQueryResult> {
  const where = whereFromFilters(filters);
  const limit = filters.limit ?? DEFAULT_LIMIT;

  const rowsQ = db
    .select()
    .from(fnoSignalReasoningTable)
    .orderBy(desc(fnoSignalReasoningTable.capturedAt))
    .limit(limit);
  const rows = where ? await rowsQ.where(where) : await rowsQ;

  // Histograms via SQL count(*) GROUP BY — runs independently of the
  // limited `rows` fetch so the buckets reflect ALL matching rows, not
  // just the 100 we surface.
  const groupBy = async (col: ReturnType<typeof sql>): Promise<Array<{ key: string; count: number }>> => {
    const q = db
      .select({ key: col, count: sql<number>`count(*)::int` })
      .from(fnoSignalReasoningTable);
    const rows = where
      ? await q.where(where).groupBy(col).orderBy(desc(sql<number>`count(*)`))
      : await q.groupBy(col).orderBy(desc(sql<number>`count(*)`));
    return rows.map(r => ({ key: r.key == null ? "UNKNOWN" : String(r.key), count: Number(r.count) }));
  };

  // For "stop reason by setup" we filter to CLOSED_STOPPED and group by
  // setup_key. Combined with the standard filters via AND.
  const stopReasonWhere = (() => {
    const stopCond = eq(fnoSignalReasoningTable.decision, "CLOSED_STOPPED");
    return where ? and(where, stopCond) : stopCond;
  })();
  const stopQ = db
    .select({
      key: sql<string>`coalesce(${fnoSignalReasoningTable.setupKey}, 'UNKNOWN')`,
      count: sql<number>`count(*)::int`,
    })
    .from(fnoSignalReasoningTable)
    .where(stopReasonWhere)
    .groupBy(fnoSignalReasoningTable.setupKey)
    .orderBy(desc(sql<number>`count(*)`));
  const stopRows = await stopQ;

  const totalQ = db
    .select({ n: sql<number>`count(*)::int` })
    .from(fnoSignalReasoningTable);
  const totalRow = where ? await totalQ.where(where) : await totalQ;
  const total = Number(totalRow[0]?.n ?? 0);

  const [byDecision, byReason, byIndex, bySetup, byTier] = await Promise.all([
    groupBy(sql`${fnoSignalReasoningTable.decision}`),
    groupBy(sql`${fnoSignalReasoningTable.reasonCode}`),
    groupBy(sql`${fnoSignalReasoningTable.indexSymbol}`),
    groupBy(sql`${fnoSignalReasoningTable.setupKey}`),
    groupBy(sql`${fnoSignalReasoningTable.tier}`),
  ]);

  return {
    rows,
    histogram: {
      byDecision,
      byReason,
      byIndex,
      bySetup,
      byTier,
      byStopReason: stopRows.map(r => ({ key: String(r.key), count: Number(r.count) })),
      total,
    },
    filters,
  };
}

/* keep ascending exported for possible future "oldest-first" route option */
export { asc };
