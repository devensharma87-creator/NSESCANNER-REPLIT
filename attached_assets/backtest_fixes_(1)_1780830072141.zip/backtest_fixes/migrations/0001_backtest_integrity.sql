-- migrations/0001_backtest_integrity.sql
-- ===========================================================================
-- Additive integrity migration for Backtest Lab.
-- Safe to run on a live DB: adds an index + a nullable column, then a
-- one-time dedupe of the historical signal storm. No columns dropped.
-- ===========================================================================

-- --- Defect 1: enforce one row per signal fingerprint --------------------
-- Step 1: collapse existing duplicates BEFORE adding the unique index,
-- keeping the most-recent capture per fingerprint. Archive the rest.

CREATE TABLE IF NOT EXISTS fno_signal_reasoning_archive_pre_dedupe
  (LIKE fno_signal_reasoning INCLUDING ALL);

-- Move all-but-latest duplicates into the archive.
WITH ranked AS (
  SELECT id,
         ROW_NUMBER() OVER (
           PARTITION BY signal_fingerprint
           ORDER BY captured_at DESC, id DESC
         ) AS rn
  FROM fno_signal_reasoning
  WHERE signal_fingerprint IS NOT NULL AND signal_fingerprint <> ''
)
INSERT INTO fno_signal_reasoning_archive_pre_dedupe
SELECT s.* FROM fno_signal_reasoning s
JOIN ranked r ON r.id = s.id
WHERE r.rn > 1;

DELETE FROM fno_signal_reasoning s
USING ranked r
WHERE r.id = s.id AND r.rn > 1;

-- Step 2: the unique index that prevents the storm from recurring.
CREATE UNIQUE INDEX IF NOT EXISTS ux_fno_signal_fingerprint
  ON fno_signal_reasoning (signal_fingerprint)
  WHERE signal_fingerprint IS NOT NULL AND signal_fingerprint <> '';

-- --- Defect 2: idempotent runs -------------------------------------------
ALTER TABLE backtest_runs
  ADD COLUMN IF NOT EXISTS run_key text;

CREATE INDEX IF NOT EXISTS ix_backtest_runs_run_key
  ON backtest_runs (run_key);

-- Optional: prevent future duplicate COMPLETE runs at the DB level.
CREATE UNIQUE INDEX IF NOT EXISTS ux_backtest_runs_runkey_complete
  ON backtest_runs (run_key)
  WHERE run_key IS NOT NULL AND status = 'COMPLETE';

-- --- Defect 5: quarantine flag on trades ---------------------------------
ALTER TABLE backtest_trades
  ADD COLUMN IF NOT EXISTS data_quality_flag text;
