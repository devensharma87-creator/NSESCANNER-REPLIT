// verify.mjs — runs the pure logic from the TS modules (ported, no TS deps)
// to prove correctness against the real exported data.
import { createReadStream } from "fs";
import { parse } from "csv-parse";

const UPLOADS = "/mnt/user-data/uploads";
let pass = 0, fail = 0;
const ok = (name, cond) => { cond ? pass++ : fail++; console.log(`${cond ? "PASS" : "FAIL"}  ${name}`); };

// ---- ported logic ----
const IST = 330, OPEN = 555, CLOSE = 930;
const clean = (s) => String(s).replace(/"/g, "").trim();       // strip stray embedded quotes
const istMin = (iso) => { const d = new Date(clean(iso)); return ((d.getUTCHours()*60+d.getUTCMinutes()+IST)%1440+1440)%1440; };
const within = (iso) => { const m = istMin(iso); return m >= OPEN && m <= CLOSE; };

function computeRunSummary(trades) {
  const dec = trades.filter(t => t.pnl!==""&&t.pnl!=null&&!Number.isNaN(Number(t.pnl))).map(t=>Number(t.pnl));
  const wins=dec.filter(p=>p>0), losses=dec.filter(p=>p<0);
  const gp=wins.reduce((a,b)=>a+b,0), gl=Math.abs(losses.reduce((a,b)=>a+b,0));
  let eq=0,peak=0,dd=0; for(const p of dec){eq+=p;peak=Math.max(peak,eq);dd=Math.max(dd,peak-eq);}
  const r2=n=>Math.round(n*100)/100;
  return {decided:dec.length,wins:wins.length,losses:losses.length,
    winRate:dec.length?r2(100*wins.length/dec.length):null,totalPnl:r2(dec.reduce((a,b)=>a+b,0)),
    profitFactor:gl>0?r2(gp/gl):null,maxDrawdown:r2(dd)};
}

function evalRR(i, minRR=1.5){
  const v=x=>x!=null&&x!==""&&Number.isFinite(Number(x));
  if(v(i.oe)&&v(i.os)&&v(i.ot)){const r=Math.abs(i.oe-i.os),w=Math.abs(i.ot-i.oe);if(r>0)return{basis:"OPTION",ratio:w/r};}
  if(v(i.se)&&v(i.ss)&&v(i.st)){const r=Math.abs(i.se-i.ss),w=Math.abs(i.st-i.se);if(r>0)return{basis:"SPOT",ratio:w/r};}
  return{basis:"UNAVAILABLE",ratio:null};
}

function fingerprint(s){
  const q=v=>v==null||v===""?"":Math.round(Number(v)*100)/100;
  const parts=[s.signal_date,s.index_symbol,s.setup_key,s.direction,q(s.selected_strike),q(s.spot_entry),q(s.spot_stop),q(s.spot_target1)];
  let h=5381; const str=parts.join("|"); for(let i=0;i<str.length;i++)h=((h<<5)+h+str.charCodeAt(i))|0;
  return (h>>>0).toString(16);
}

function loadCsv(path){return new Promise((res,rej)=>{const rows=[];createReadStream(path)
  .pipe(parse({columns:true,relax_quotes:true,skip_records_with_error:true}))
  .on("data",r=>rows.push(r)).on("end",()=>res(rows)).on("error",rej);});}

// ---- run ----
const trades = await loadCsv(`${UPLOADS}/backtest_trades.csv`);
const sig = await loadCsv(`${UPLOADS}/fno_signal_reasoning.csv`);

// TEST 1: summary on real-replay run matches the persisted DB summary
const real = trades.filter(t=>t.run_id.slice(0,8)==="df39d235");
const sum = computeRunSummary(real);
console.log("\n-- recomputed real-replay summary --"); console.log(sum);
ok("decided trades == 18", sum.decided===18);
ok("net pnl == -21541.55", sum.totalPnl===-21541.55);
ok("win rate == 16.67", sum.winRate===16.67);
ok("profit factor == 0.42", sum.profitFactor===0.42);

// TEST 2: IST conversion fixes the false session-validity alarm
const utcFlagged = real.filter(t=>{ // naive UTC check (the bug)
  const e=new Date(clean(t.entry_at)),x=new Date(clean(t.exit_at));
  const em=e.getUTCHours()*60+e.getUTCMinutes(), xm=x.getUTCHours()*60+x.getUTCMinutes();
  return em<OPEN||em>CLOSE||xm<OPEN||xm>CLOSE;}).length;
const istFlagged = real.filter(t=>!within(t.entry_at)||!within(t.exit_at)).length;
console.log(`\nUTC-naive flagged: ${utcFlagged}, IST-correct flagged: ${istFlagged}`);
ok("UTC bug over-flags vs IST", utcFlagged > istFlagged);
ok("IST-correct count is the real 13", istFlagged===13);

// TEST 3: fingerprint dedupe collapses the storm
const emitted = sig.filter(s=>s.decision==="EMITTED"&&s.signal_fingerprint);
const uniq = new Set(emitted.map(s=>s.signal_fingerprint));
console.log(`\nEmitted rows: ${emitted.length}, unique fingerprints: ${uniq.size}`);
ok("storm is real (>10x inflation)", emitted.length/uniq.size > 10);
// our recomputed fingerprint should also collapse them to a similar order of magnitude
const recomputed = new Set(emitted.map(fingerprint));
ok("recomputed fingerprint also collapses", recomputed.size < emitted.length/10);

// TEST 4: R:R fallback — spot R:R is healthy, option R:R unavailable
let optAvail=0, spotPass=0, spotTotal=0;
for(const s of emitted){
  const r=evalRR({oe:s.option_entry,os:s.option_stop,ot:s.option_target1,
                  se:s.spot_entry,ss:s.spot_stop,st:s.spot_target1});
  if(r.basis==="OPTION")optAvail++;
  if(r.basis==="SPOT"){spotTotal++; if(r.ratio>=1.5)spotPass++;}
}
console.log(`\nR:R basis: option=${optAvail}, spot=${spotTotal}, spot>=1.5: ${spotPass}`);
ok("option R:R unavailable (data gap)", optAvail===0);
ok("spot fallback rescues >85% of signals", spotPass/spotTotal > 0.85);

console.log(`\n==== ${pass} passed, ${fail} failed ====`);
process.exit(fail?1:0);
