/**
 * test/fnoTaxonomy.test.ts
 * ---------------------------------------------------------------------------
 * Regression tests for the F&O signal-reasoning defects (F4, F5, F6, F7).
 */
import { describe, it, expect } from "vitest";
import {
  classifyTier,
  assertTierBandsCoherent,
  reconcileDecision,
  isValidLifecycle,
  sanitizeLifecycle,
} from "../services/signalTaxonomy";
import { KiteSessionGate, RejectionThrottle } from "../services/kiteSessionGate";

describe("F6 — tier bands are non-overlapping", () => {
  it("does not crash and bands are coherent", () => {
    expect(() => assertTierBandsCoherent()).not.toThrow();
  });
  it("classifies confidence into a single tier (no overlap)", () => {
    expect(classifyTier(78)).toBe("HIGH_CONVICTION"); // was wrongly BASELINE in data
    expect(classifyTier(72)).toBe("HIGH_CONVICTION");
    expect(classifyTier(65)).toBe("STANDARD");
    expect(classifyTier(52)).toBe("BASELINE");
  });
  it("returns null for missing confidence", () => {
    expect(classifyTier(null)).toBeNull();
  });
});

describe("F5 — decision is mutually exclusive", () => {
  it("reclassifies EMITTED+DEMOTED to DEMOTED", () => {
    expect(reconcileDecision("EMITTED", "DEMOTED")).toBe("DEMOTED");
  });
  it("leaves a clean emission untouched", () => {
    expect(reconcileDecision("EMITTED", "EMITTED")).toBe("EMITTED");
  });
});

describe("F4 — lifecycle state machine", () => {
  it("rejects a fill outcome on a MISSED_WINDOW signal", () => {
    expect(isValidLifecycle("MISSED_WINDOW", "TARGET1_HIT")).toBe(false);
    expect(isValidLifecycle("MISSED_WINDOW", "STOPPED")).toBe(false);
  });
  it("rejects a fill outcome on a rejected signal", () => {
    expect(isValidLifecycle("PRE_EMISSION_REJECTED", "STOPPED")).toBe(false);
  });
  it("allows a fill outcome on an emitted signal", () => {
    expect(isValidLifecycle("EMITTED", "TARGET1_HIT")).toBe(true);
  });
  it("sanitize clears the impossible value", () => {
    expect(sanitizeLifecycle("MISSED_WINDOW", "TARGET1_HIT")).toBe("");
    expect(sanitizeLifecycle("EMITTED", "TARGET1_HIT")).toBe("TARGET1_HIT");
  });
});

describe("F7 — Kite session gate stops the storm", () => {
  it("skips evaluation when the session is dead", () => {
    const gate = new KiteSessionGate();
    gate.setState("EXPIRED");
    expect(gate.shouldEvaluate().evaluate).toBe(false);
  });
  it("logs the dead session only once per interval, not per tick", () => {
    const gate = new KiteSessionGate();
    gate.setState("EXPIRED");
    const first = gate.shouldEvaluate();
    const second = gate.shouldEvaluate();
    expect(first.logDeadSession).toBe(true);
    expect(second.logDeadSession).toBe(false); // throttled
  });
  it("evaluates normally when live", () => {
    const gate = new KiteSessionGate();
    gate.setState("LIVE");
    expect(gate.shouldEvaluate().evaluate).toBe(true);
  });
});

describe("F2 — rejection throttle logs once per state change", () => {
  it("logs a new rejection, skips an identical repeat, logs on change", () => {
    const t = new RejectionThrottle();
    const id = { date: "2026-05-18", index: "NIFTY", setup: "EMA_PULLBACK", reasonCode: "CONDITIONS_NOT_MET" };
    expect(t.shouldLog(id)).toBe(true); // first
    expect(t.shouldLog(id)).toBe(false); // identical repeat -> skip
    expect(t.shouldLog({ ...id, reasonCode: "LATE_SESSION_ENTRY" })).toBe(true); // changed
  });
});
