/**
 * test/backtestIntegrity.test.ts
 * ---------------------------------------------------------------------------
 * Regression tests for the seven defects. Run with: vitest run
 * These lock the fixes in place so the duplicate storm / UI-DB drift / TZ
 * alarm can never silently return.
 */
import { describe, it, expect } from "vitest";
import {
  istMinuteOfDay,
  isWithinSession,
  clampToSquareOff,
  SESSION_CLOSE_MIN,
} from "../lib/istTime";
import { computeRunSummary, rankStrategies } from "../services/runSummary";
import { computeSignalFingerprint } from "../services/signalWriter";
import { computeRunKey } from "../services/runKey";
import { evaluateRiskReward } from "../services/riskReward";

describe("Defect 3 — IST session validity", () => {
  it("treats 09:12:27Z (14:42 IST) as in-session", () => {
    expect(istMinuteOfDay("2026-04-30T09:12:27.456Z")).toBe(14 * 60 + 42);
    expect(isWithinSession("2026-04-30T09:12:27.456Z")).toBe(true);
  });
  it("treats 06:23:04Z (11:53 IST) as in-session", () => {
    expect(isWithinSession("2026-05-06T06:23:04.295Z")).toBe(true);
  });
  it("rejects 13:54Z (19:24 IST, post-close corrupt)", () => {
    expect(isWithinSession("2026-05-01T13:54:00.000Z")).toBe(false);
  });
});

describe("Defect 4 — square-off clamp", () => {
  it("clamps an exit past 15:30 IST back to 15:30", () => {
    const { at, clamped } = clampToSquareOff("2026-05-06T10:08:00.000Z"); // 15:38 IST
    expect(clamped).toBe(true);
    expect(istMinuteOfDay(at)).toBe(SESSION_CLOSE_MIN);
  });
  it("leaves an in-session exit untouched", () => {
    const { clamped } = clampToSquareOff("2026-05-06T08:00:00.000Z"); // 13:30 IST
    expect(clamped).toBe(false);
  });
});

describe("Defect 7 — single summary function", () => {
  it("computes PF, win rate, drawdown deterministically", () => {
    const trades = [
      { pnl: 1000 }, { pnl: -500 }, { pnl: -500 }, { pnl: 2000 }, { pnl: null },
    ];
    const s = computeRunSummary(trades);
    expect(s.decidedTrades).toBe(4);
    expect(s.totalPnl).toBe(2000);
    expect(s.winRate).toBe(50);
    expect(s.profitFactor).toBe(3); // 3000 / 1000
  });
  it("returns null PF when there are no losses (no divide-by-zero)", () => {
    expect(computeRunSummary([{ pnl: 100 }]).profitFactor).toBeNull();
  });
});

describe("Defect 6 — ranking eligibility gate", () => {
  it("never awards a strategy below the trade threshold", () => {
    const awards = rankStrategies(
      [{
        strategyId: "ORB_BREAKOUT", strategyName: "Opening Range Breakout",
        totalTrades: 0, netPnl: 0, winRate: null, profitFactor: null,
        avgR: null, maxDrawdown: 0, consistency: null, compositeScore: null,
      }],
      10
    );
    for (const a of awards) expect(a.strategyId).toBeNull();
  });
});

describe("Defect 1 — fingerprint stability", () => {
  it("is identical across poll ticks (no captured_at in the key)", () => {
    const base = {
      signalDate: "2026-05-18", indexSymbol: "NIFTY", setupKey: "ORB_BREAKOUT",
      direction: "BULLISH", selectedStrike: 24100, spotEntry: 24050,
      spotStop: 23980, spotTarget1: 24190,
    };
    const a = computeSignalFingerprint(base);
    const b = computeSignalFingerprint({ ...base }); // same signal, later poll
    expect(a).toBe(b);
  });
  it("changes when the setup levels change", () => {
    const a = computeSignalFingerprint({
      signalDate: "2026-05-18", indexSymbol: "NIFTY", setupKey: "ORB_BREAKOUT",
      direction: "BULLISH", selectedStrike: 24100, spotEntry: 24050,
      spotStop: 23980, spotTarget1: 24190,
    });
    const b = computeSignalFingerprint({
      signalDate: "2026-05-18", indexSymbol: "NIFTY", setupKey: "ORB_BREAKOUT",
      direction: "BULLISH", selectedStrike: 24200, spotEntry: 24050,
      spotStop: 23980, spotTarget1: 24190,
    });
    expect(a).not.toBe(b);
  });
});

describe("Defect 2 — run key idempotency", () => {
  it("is order-insensitive on selected strategies", () => {
    const base = {
      ownerKey: "dev", backtestMode: "STRATEGY_RESEARCH", instrument: "ALL",
      timeframe: "15m", fromDate: "2026-06-05", toDate: "2026-06-26",
      startingCapital: 1_000_000, riskPerTradePct: 1, filters: {}, params: {},
    };
    const a = computeRunKey({ ...base, selectedStrategies: ["ORB_BREAKOUT", "VWAP_PULLBACK"] });
    const b = computeRunKey({ ...base, selectedStrategies: ["VWAP_PULLBACK", "ORB_BREAKOUT"] });
    expect(a).toBe(b);
  });
});

describe("R:R spot fallback", () => {
  it("uses option R:R when premiums exist", () => {
    const r = evaluateRiskReward({
      spotEntry: 100, spotStop: 95, spotTarget1: 110,
      optionEntry: 50, optionStop: 40, optionTarget1: 80,
    });
    expect(r.basis).toBe("OPTION");
    expect(r.passes).toBe(true); // 30/10 = 3.0
  });
  it("falls back to spot R:R when premiums are absent", () => {
    const r = evaluateRiskReward({ spotEntry: 100, spotStop: 95, spotTarget1: 110 });
    expect(r.basis).toBe("SPOT");
    expect(r.ratio).toBeCloseTo(2.0);
  });
  it("flags a true data gap rather than blocking on risk", () => {
    const r = evaluateRiskReward({ spotEntry: null, spotStop: null, spotTarget1: null });
    expect(r.basis).toBe("UNAVAILABLE");
  });
});
