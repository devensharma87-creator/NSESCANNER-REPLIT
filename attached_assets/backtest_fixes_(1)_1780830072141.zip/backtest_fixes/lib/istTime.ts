/**
 * lib/istTime.ts
 * ---------------------------------------------------------------------------
 * Single source of truth for IST session arithmetic.
 *
 * Fixes:
 *   Defect 3 — session-validity check compared UTC clock values against the
 *              IST window. ALWAYS convert before comparing.
 *   Defect 4 — exits drifting past 15:30. clampToSquareOff() pins them.
 *   Defect 5 — corrupt post-close entries. isWithinSession() rejects them.
 *
 * Additive: this is a new file. Nothing else changes its behaviour until the
 * callers below are wired to it.
 */

export const IST_OFFSET_MIN = 5 * 60 + 30; // +05:30, no DST in India
export const SESSION_OPEN_MIN = 9 * 60 + 15; // 09:15 IST
export const SESSION_CLOSE_MIN = 15 * 60 + 30; // 15:30 IST

/** Parse a stored UTC instant (ISO string or Date) to a Date in UTC. */
export function toUtcDate(ts: string | Date): Date {
  return ts instanceof Date ? ts : new Date(ts);
}

/** Minute-of-day in IST for a stored UTC instant. */
export function istMinuteOfDay(ts: string | Date): number {
  const d = toUtcDate(ts);
  // getUTC* gives the UTC wall clock; add the IST offset, wrap at 1440.
  const utcMin = d.getUTCHours() * 60 + d.getUTCMinutes();
  return ((utcMin + IST_OFFSET_MIN) % 1440 + 1440) % 1440;
}

/** IST calendar date key (YYYY-MM-DD) for a stored UTC instant. */
export function istDateKey(ts: string | Date): string {
  const d = toUtcDate(ts);
  const shifted = new Date(d.getTime() + IST_OFFSET_MIN * 60_000);
  return shifted.toISOString().slice(0, 10);
}

/** True if the instant falls inside 09:15–15:30 IST (inclusive). */
export function isWithinSession(ts: string | Date): boolean {
  const m = istMinuteOfDay(ts);
  return m >= SESSION_OPEN_MIN && m <= SESSION_CLOSE_MIN;
}

/**
 * Clamp an exit instant to 15:30 IST if it spilled past square-off.
 * Returns the original instant if already in-session.
 * The returned Date is in UTC (same storage convention as the input).
 */
export function clampToSquareOff(ts: string | Date): { at: Date; clamped: boolean } {
  const d = toUtcDate(ts);
  const m = istMinuteOfDay(d);
  if (m <= SESSION_CLOSE_MIN) return { at: d, clamped: false };
  // Build 15:30 IST on the same IST date, then convert back to UTC.
  const istShifted = new Date(d.getTime() + IST_OFFSET_MIN * 60_000);
  istShifted.setUTCHours(15, 30, 0, 0); // 15:30 on the IST calendar day
  const backToUtc = new Date(istShifted.getTime() - IST_OFFSET_MIN * 60_000);
  return { at: backToUtc, clamped: true };
}

/** Human IST string for logs/UI, e.g. "2026-05-06 11:53 IST". */
export function formatIst(ts: string | Date): string {
  const d = toUtcDate(ts);
  const shifted = new Date(d.getTime() + IST_OFFSET_MIN * 60_000);
  const pad = (n: number) => String(n).padStart(2, "0");
  return (
    `${shifted.getUTCFullYear()}-${pad(shifted.getUTCMonth() + 1)}-${pad(shifted.getUTCDate())} ` +
    `${pad(shifted.getUTCHours())}:${pad(shifted.getUTCMinutes())} IST`
  );
}
