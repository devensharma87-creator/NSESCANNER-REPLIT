# Backtest Lab — Fix & Improvement Bundle

Drop-in TypeScript for the seven defects in the Backtest Lab audit, plus
net-new integrity tooling. Every module is **additive** — it introduces new
files and one additive migration; nothing is deleted. Wire the call-sites as
noted below.

All logic here was verified against your real exported data
(`fixes/verify.mjs`, 10/10 passing). The Vitest spec
(`test/backtestIntegrity.test.ts`) locks the fixes so they can't silently
regress.

---

## File map

| File | Fixes | What it does |
|------|-------|--------------|
| `lib/istTime.ts` | 3, 4, 5 | IST conversion, session window, 15:30 square-off clamp |
| `services/signalWriter.ts` | 1 | Fingerprint **upsert** — one row per signal, not per poll |
| `services/runKey.ts` | 2 | Deterministic run key + `runOrReuse()` idempotency guard |
| `services/runSummary.ts` | 6, 7 | The **one** summary function + ranking eligibility gate |
| `services/riskReward.ts` | research all-block | Option R:R with **spot fallback** when premiums are absent |
| `migrations/0001_backtest_integrity.sql` | 1, 2, 5 | Unique fingerprint index, run_key column, one-time dedupe |
| `services/dataHealth.ts` | addition | Infra-Health probe (storm / dupes / coverage / hygiene) |
| `services/nightlyDedup.ts` | addition | The dedupe cron that never ran, now idempotent + lock-safe |
| `services/kiteSessionGate.ts` | F7, storm | Stops per-tick rejection logging on a dead Kite session |
| `services/signalTaxonomy.ts` | F4, F5, F6 | Non-overlapping tiers, mutually-exclusive decisions, lifecycle guard |
| `test/backtestIntegrity.test.ts` | all backtest | Regression tests |
| `test/fnoTaxonomy.test.ts` | F4–F7 | F&O regression tests |

> Adjust the schema import paths (`../db/schema`) to your monorepo's barrel.

---

## Apply in this order (sequence matters)

**1. Migration first.** Dedupe before you trust any counts.
```bash
psql "$DATABASE_URL" -f migrations/0001_backtest_integrity.sql
```
This collapses the historical storm into the archive table and adds the unique
index so it can't recur.

**2. Swap the signal write path.** Wherever the engine currently does
`INSERT INTO fno_signal_reasoning`, call `upsertSignal(db, row)` instead. Use
its `isNew` return to drive the alerter (notify only on genuinely-new signals).

**3. Guard the backtest run path.** In the `POST /backtest` handler, wrap
execution:
```ts
const { runId, cached } = await runOrReuse(db, inputs, async (runKey) => {
  // ...existing run execution, but persist `runKey` on the run row...
  return { runId: created.id };
});
return res.json({ runId, cached });
```

**4. Collapse the two summary paths.** Delete the UI-side recompute. The API
returns the persisted summary produced by `computeRunSummary()`; the client
renders it verbatim. This is what removes the 26-vs-18 / −48,411-vs-−21,542
contradiction.

**5. Gate the ranking.** Replace the `byStrategy[0]` award logic with
`rankStrategies(stats, 10)` (your "fewer than 10 trades are ineligible" rule).

**6. Fix research-mode R:R.** Replace the option-premium R:R check with
`evaluateRiskReward(levels, minRR)`. It uses real option R:R when present and
falls back to spot R:R otherwise, so setups stop blocking on
`minimumRiskReward` purely because the option layer is empty.

**7. Schedule the cron + expose health.**
```ts
// nightly, single-leader
await runNightlyDedup(db);
// GET /api/infra/data-health
res.json(await getDataHealth(db));
```

---

## F&O signal engine — additional wiring

The signal-reasoning file (`fno_signal_reasoning`) had its own defects beyond
the duplicate storm. Run `fno_repair.py` for the one-time historical cleanup
(54x row reduction: 44,915 -> 827 real events), then wire the engine:

**8. Stop the storm at source.** In the polling loop, gate evaluation on the
Kite session and throttle rejection logging:
```ts
const gate = new KiteSessionGate();          // module-level, per index
const throttle = new RejectionThrottle();
// each tick:
gate.setState(await probeKiteSession());
const { evaluate, logDeadSession } = gate.shouldEvaluate();
if (!evaluate) { if (logDeadSession) logOnce("kite session dead"); return; }
// ...evaluate strategies...
if (rejected && throttle.shouldLog({ date, index, setup, reasonCode }))
  await upsertSignal(db, rejectionRow);       // log once per state change
```

**9. Enforce the taxonomy.** Before persisting any signal row:
```ts
const decision  = reconcileDecision(rawDecision, reasonCode); // F5
const tier      = classifyTier(confidence);                   // F6
const lifecycle = sanitizeLifecycle(decision, rawLifecycle);  // F4
```
Call `assertTierBandsCoherent()` at boot so a future threshold edit that makes
the bands overlap fails fast instead of silently mis-tiering signals.

**10. Always fingerprint on emit (F8).** 77 emitted rows had no fingerprint.
`computeSignalFingerprint()` must run for every emission, not just some — the
unique index from migration 0001 depends on it.

---

## OpenAPI delta (OpenAPI-first)

Add these to the spec so codegen stays the source of truth:

- `POST /backtest` response: add `cached: boolean`.
- `GET /api/infra/data-health` → `DataHealthReport` (see `dataHealth.ts` types).
- No change to signal enums or trade schema beyond the additive
  `data_quality_flag` column and the `run_key` field.

---

## Constraints honoured

- **Additive-only** — new files + additive migration; no drops, no destructive edits.
- **Signal-enum separation** — the writer stores raw `decision` / `lifecycle_status`
  enums only; display labels are never persisted here.
- **Paper-only** — no order side effects anywhere in this bundle.
- **Railway-safe** — the dedup job and run guard rely on the DB + advisory locks,
  not in-memory state, so they survive restarts and multi-replica.

---

## Note on the empty option layer

Across all 44,915 master rows the option columns
(`option_entry/stop/target/exit/oi/ltp`) are 0–0.03% populated. The spot-R:R
fallback is the correct interim behaviour, but the real fix is capture
coverage. `getDataHealth()` now reports this as a first-class metric so you can
watch it climb as Mode-D capture accumulates, rather than discovering gaps in a
post-hoc CSV.
