/**
 * services/runKey.ts
 * ---------------------------------------------------------------------------
 * Fixes Defect 2 — re-running a backtest with identical inputs wrote a NEW
 * run row + a fresh copy of every trade. 14 of 34 trade-producing runs in the
 * export were exact duplicates.
 *
 * Strategy: derive a deterministic run_key from the inputs that define a run.
 * Before executing, look up an existing COMPLETE run with the same key and
 * return it (cache hit) instead of recomputing and re-inserting.
 *
 * Constraints respected:
 *   - additive-only: adds a nullable run_key column + a guard. Existing runs
 *     without a key are untouched and still readable.
 *   - OpenAPI-first: the guard lives behind the existing POST /backtest path;
 *     no schema-visible contract change beyond an optional `cached` flag.
 */

import { sql, and, eq } from "drizzle-orm";
import type { PgDatabase } from "drizzle-orm/pg-core";
import { backtestRuns } from "../db/schema";

export interface RunInputs {
  ownerKey: string;
  backtestMode: string; // OFFICIAL_ENGINE | STRATEGY_RESEARCH | REAL_REPLAY
  instrument: string; // ALL | NIFTY | BANKNIFTY | SENSEX
  timeframe: string;
  fromDate: string;
  toDate: string;
  startingCapital: number;
  riskPerTradePct: number;
  selectedStrategies: string[]; // order-insensitive
  filters: Record<string, unknown>;
  params: Record<string, unknown>;
}

/** Deterministic, order-insensitive key. Same inputs => same key. */
export function computeRunKey(inp: RunInputs): string {
  const norm = {
    o: inp.ownerKey,
    m: inp.backtestMode,
    i: inp.instrument,
    tf: inp.timeframe,
    f: inp.fromDate,
    t: inp.toDate,
    cap: inp.startingCapital,
    risk: inp.riskPerTradePct,
    strat: [...inp.selectedStrategies].sort(), // order-insensitive
    filt: sortedJson(inp.filters),
    par: sortedJson(inp.params),
  };
  const str = JSON.stringify(norm);
  let h = 5381;
  for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
  return "rk_" + (h >>> 0).toString(16).padStart(8, "0");
}

function sortedJson(obj: Record<string, unknown>): Record<string, unknown> {
  return Object.keys(obj)
    .sort()
    .reduce((acc, k) => {
      acc[k] = obj[k];
      return acc;
    }, {} as Record<string, unknown>);
}

/**
 * Wrap a backtest execution with idempotency.
 * If a COMPLETE run with the same key exists, return it (no recompute).
 * Otherwise run `execute()`, persist with the key, and return it.
 */
export async function runOrReuse(
  db: PgDatabase<any>,
  inp: RunInputs,
  execute: (runKey: string) => Promise<{ runId: string }>
): Promise<{ runId: string; cached: boolean }> {
  const runKey = computeRunKey(inp);

  const existing = await db
    .select({ id: backtestRuns.id })
    .from(backtestRuns)
    .where(and(eq(backtestRuns.runKey, runKey), eq(backtestRuns.status, "COMPLETE")))
    .limit(1);

  if (existing.length > 0) {
    return { runId: existing[0].id, cached: true };
  }

  const { runId } = await execute(runKey);
  return { runId, cached: false };
}
