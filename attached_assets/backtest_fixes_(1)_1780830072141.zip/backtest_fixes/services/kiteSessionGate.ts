/**
 * services/kiteSessionGate.ts
 * ---------------------------------------------------------------------------
 * Fixes F7 — the Kite-session reject storm.
 *
 * Diagnosis: 3,217 PRE_EMISSION_REJECTED rows carry rawReason
 *   "no_live_kite_intraday (Kite session expired / throttled) — Yahoo
 *    fallback disabled to prevent stale-data signals".
 * The engine kept polling on a dead Kite session and logged a fresh rejection
 * every tick. Correct behaviour: detect the dead session ONCE, back off, and
 * stop emitting per-tick rejection rows.
 *
 * Also fixes the upstream cause of F1/F2 (the storm): the engine should only
 * LOG a state CHANGE, not log on every poll. shouldLogRejection() enforces
 * "log once per (signal identity) until it changes or resolves".
 *
 * Stateless-friendly: the dedupe window is keyed in the DB-backed signal
 * writer (upsert), so this in-memory cache is only an optimisation and is
 * safe to lose on restart (Railway-safe).
 */

export type SessionState = "LIVE" | "EXPIRED" | "THROTTLED" | "UNKNOWN";

export interface KiteSessionStatus {
  state: SessionState;
  checkedAt: number; // epoch ms
}

export class KiteSessionGate {
  private status: KiteSessionStatus = { state: "UNKNOWN", checkedAt: 0 };
  private backoffMs = 30_000; // re-check a dead session at most every 30s
  private lastDeadLogAt = 0;
  private deadLogIntervalMs = 5 * 60_000; // log "session dead" at most every 5 min

  /** Update from a health probe / Kite API response. */
  setState(state: SessionState) {
    this.status = { state, checkedAt: Date.now() };
  }

  isLive(): boolean {
    return this.status.state === "LIVE";
  }

  /**
   * Should the engine even attempt signal evaluation this tick?
   * If the session is dead, skip evaluation (and thus skip the per-tick
   * rejection row) — but allow ONE throttled "session dead" log per interval
   * so the operator still sees the condition.
   */
  shouldEvaluate(): { evaluate: boolean; logDeadSession: boolean } {
    if (this.isLive()) return { evaluate: true, logDeadSession: false };
    const now = Date.now();
    const shouldLog = now - this.lastDeadLogAt >= this.deadLogIntervalMs;
    if (shouldLog) this.lastDeadLogAt = now;
    return { evaluate: false, logDeadSession: shouldLog };
  }

  /** Whether it's time to re-probe a dead session. */
  shouldReprobe(): boolean {
    return Date.now() - this.status.checkedAt >= this.backoffMs;
  }
}

/**
 * Rejection log throttle (fixes the F2 reject storm at source).
 * Logs a rejection only when the (signal identity, reason) is NEW or CHANGED
 * within the session, instead of once per poll.
 *
 * Use the SAME identity as the signal fingerprint minus the price levels:
 * (date, index, setup, reasonCode). In-memory; DB upsert is the durable guard.
 */
export class RejectionThrottle {
  private seen = new Map<string, string>(); // identity -> last reasonCode

  shouldLog(identity: { date: string; index: string; setup: string; reasonCode: string }): boolean {
    const key = `${identity.date}|${identity.index}|${identity.setup}`;
    const prev = this.seen.get(key);
    if (prev === identity.reasonCode) return false; // unchanged -> skip
    this.seen.set(key, identity.reasonCode);
    return true; // new or changed reason -> log once
  }

  /** Call at session rollover (new trading day) to reset. */
  resetForNewSession() {
    this.seen.clear();
  }
}
