/**
 * services/nightlyDedup.ts
 * ---------------------------------------------------------------------------
 * ADDITION (net-new). The dedupe job that was supposed to exist but never ran
 * (its archive file was 0 bytes). Idempotent and safe to run nightly.
 *
 * With the UNIQUE index from migration 0001 in place, the storm can't recur on
 * the write path. This job is the belt-and-braces sweep for anything that
 * slipped in before the index, plus it prunes the archive.
 *
 * IMPORTANT for the Railway migration: this is stateless and safe under
 * multi-replica / restart conditions (it relies on the DB, not in-memory
 * dedup rings). Schedule it with a single-leader lock if you run >1 replica.
 */

import { sql } from "drizzle-orm";
import type { PgDatabase } from "drizzle-orm/pg-core";

export interface DedupResult {
  archived: number;
  remaining: number;
  ranAt: string;
}

export async function runNightlyDedup(db: PgDatabase<any>): Promise<DedupResult> {
  // Advisory lock so only one replica performs the sweep.
  const lock = await db.execute(sql`SELECT pg_try_advisory_lock(918273645) AS got`);
  if (!((lock as any).rows[0].got)) {
    return { archived: 0, remaining: -1, ranAt: new Date().toISOString() };
  }

  try {
    const moved = await db.execute(sql`
      WITH ranked AS (
        SELECT id, ROW_NUMBER() OVER (
                 PARTITION BY signal_fingerprint
                 ORDER BY captured_at DESC, id DESC) AS rn
        FROM fno_signal_reasoning
        WHERE signal_fingerprint IS NOT NULL AND signal_fingerprint <> ''
      ),
      moved AS (
        INSERT INTO fno_signal_reasoning_archive_pre_dedupe
        SELECT s.* FROM fno_signal_reasoning s
        JOIN ranked r ON r.id = s.id WHERE r.rn > 1
        RETURNING 1
      )
      SELECT COUNT(*)::int AS n FROM moved
    `);
    const archived = (moved as any).rows[0].n;

    await db.execute(sql`
      DELETE FROM fno_signal_reasoning s
      USING (
        SELECT id, ROW_NUMBER() OVER (
                 PARTITION BY signal_fingerprint
                 ORDER BY captured_at DESC, id DESC) AS rn
        FROM fno_signal_reasoning
        WHERE signal_fingerprint IS NOT NULL AND signal_fingerprint <> ''
      ) r
      WHERE r.id = s.id AND r.rn > 1
    `);

    const rem = await db.execute(sql`SELECT COUNT(*)::int AS n FROM fno_signal_reasoning`);
    return {
      archived,
      remaining: (rem as any).rows[0].n,
      ranAt: new Date().toISOString(),
    };
  } finally {
    await db.execute(sql`SELECT pg_advisory_unlock(918273645)`);
  }
}
