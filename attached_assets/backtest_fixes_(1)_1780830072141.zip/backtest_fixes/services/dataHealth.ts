/**
 * services/dataHealth.ts
 * ---------------------------------------------------------------------------
 * ADDITION (net-new). A read-only health probe for the Infra Health roll-up.
 *
 * Surfaces the exact failure modes this audit found, so they show up on a
 * dashboard tile instead of being discovered months later in a CSV export:
 *   - signal duplication ratio (storm detector)
 *   - duplicate-run count
 *   - option-chain capture coverage
 *   - timestamp hygiene (stray quotes, post-close entries)
 *   - UI/DB summary drift
 *
 * Returns a structured report with a GREEN/AMBER/RED status per check.
 */

import { sql } from "drizzle-orm";
import type { PgDatabase } from "drizzle-orm/pg-core";

export type HealthStatus = "GREEN" | "AMBER" | "RED";

export interface HealthCheck {
  key: string;
  label: string;
  status: HealthStatus;
  value: string;
  detail: string;
}

export interface DataHealthReport {
  generatedAt: string;
  overall: HealthStatus;
  checks: HealthCheck[];
}

const worst = (a: HealthStatus, b: HealthStatus): HealthStatus => {
  const rank = { GREEN: 0, AMBER: 1, RED: 2 } as const;
  return rank[a] >= rank[b] ? a : b;
};

export async function getDataHealth(db: PgDatabase<any>): Promise<DataHealthReport> {
  const checks: HealthCheck[] = [];

  // 1. Signal duplication ratio
  const dup = await db.execute(sql`
    SELECT COUNT(*)::int AS rows,
           COUNT(DISTINCT signal_fingerprint)::int AS uniq
    FROM fno_signal_reasoning
    WHERE decision = 'EMITTED' AND signal_fingerprint IS NOT NULL
  `);
  const { rows: r, uniq } = (dup as any).rows[0];
  const ratio = uniq > 0 ? r / uniq : 1;
  checks.push({
    key: "signal_dup_ratio",
    label: "Signal duplication ratio",
    status: ratio <= 1.05 ? "GREEN" : ratio <= 1.5 ? "AMBER" : "RED",
    value: `${ratio.toFixed(2)}x`,
    detail: `${r} rows / ${uniq} unique fingerprints (target ~1.0x)`,
  });

  // 2. Duplicate COMPLETE runs sharing a run_key
  const dupRuns = await db.execute(sql`
    SELECT COUNT(*)::int AS dupes FROM (
      SELECT run_key FROM backtest_runs
      WHERE run_key IS NOT NULL AND status = 'COMPLETE'
      GROUP BY run_key HAVING COUNT(*) > 1
    ) t
  `);
  const dupes = (dupRuns as any).rows[0].dupes;
  checks.push({
    key: "duplicate_runs",
    label: "Duplicate backtest runs",
    status: dupes === 0 ? "GREEN" : "RED",
    value: String(dupes),
    detail: "run_keys with more than one COMPLETE run",
  });

  // 3. Option-chain capture coverage (of emitted signals)
  const cov = await db.execute(sql`
    SELECT COUNT(*)::int AS total,
           COUNT(option_exit)::int AS with_exit
    FROM fno_signal_reasoning WHERE decision = 'EMITTED'
  `);
  const { total, with_exit } = (cov as any).rows[0];
  const covPct = total > 0 ? (100 * with_exit) / total : 0;
  checks.push({
    key: "option_capture",
    label: "Option-exit capture coverage",
    status: covPct >= 50 ? "GREEN" : covPct >= 10 ? "AMBER" : "RED",
    value: `${covPct.toFixed(1)}%`,
    detail: `${with_exit}/${total} emitted signals have a captured option exit`,
  });

  // 4. Timestamp hygiene — stray-quoted or unparseable entry timestamps
  const badTs = await db.execute(sql`
    SELECT COUNT(*)::int AS bad FROM backtest_trades
    WHERE entry_at::text LIKE '%"%'
  `);
  const bad = (badTs as any).rows[0].bad;
  checks.push({
    key: "timestamp_hygiene",
    label: "Timestamp hygiene",
    status: bad === 0 ? "GREEN" : "AMBER",
    value: String(bad),
    detail: "trade rows with stray-quoted timestamps",
  });

  const overall = checks.reduce<HealthStatus>((acc, c) => worst(acc, c.status), "GREEN");
  return { generatedAt: new Date().toISOString(), overall, checks };
}
