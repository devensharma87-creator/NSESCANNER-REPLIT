/**
 * services/runSummary.ts
 * ---------------------------------------------------------------------------
 * Fixes Defect 7 — the UI computed its own summary (26 / -48,411 / PF 0.27)
 * while the persisted run.summary said 18 / -21,542 / PF 0.42. Two divergent
 * calc paths can never agree.
 *
 * Rule: there is ONE summary function. Persistence calls it at run time; the
 * API returns the persisted result; the UI renders that result and never
 * recomputes. If the UI needs a number, it reads it from here.
 *
 * Also fixes Defect 6 — ranking awarded "Best Overall" to a 0-trade strategy.
 * rankStrategies() gates every award behind an eligibility threshold.
 */

export interface TradeRow {
  pnl: number | null | string;
  setupKey?: string;
  // ...other fields present but unused for the summary math
}

export interface RunSummary {
  totalSignals: number;
  decidedTrades: number;
  wins: number;
  losses: number;
  breakeven: number;
  winRate: number | null; // %
  totalPnl: number;
  grossProfit: number;
  grossLoss: number;
  profitFactor: number | null;
  expectancy: number | null;
  maxDrawdown: number;
  bestTradePnl: number | null;
  worstTradePnl: number | null;
}

const isDecided = (t: TradeRow) =>
  t.pnl !== null && t.pnl !== "" && t.pnl !== "null" && !Number.isNaN(Number(t.pnl));

/** THE summary function. Deterministic. No I/O. Call once; store; reuse. */
export function computeRunSummary(trades: TradeRow[]): RunSummary {
  const decided = trades.filter(isDecided).map((t) => Number(t.pnl));
  const wins = decided.filter((p) => p > 0);
  const losses = decided.filter((p) => p < 0);
  const breakeven = decided.filter((p) => p === 0);

  const grossProfit = wins.reduce((a, b) => a + b, 0);
  const grossLoss = Math.abs(losses.reduce((a, b) => a + b, 0));
  const totalPnl = decided.reduce((a, b) => a + b, 0);

  // Drawdown on the realised equity sequence (trade order preserved).
  let eq = 0,
    peak = 0,
    maxDd = 0;
  for (const p of decided) {
    eq += p;
    peak = Math.max(peak, eq);
    maxDd = Math.max(maxDd, peak - eq);
  }

  const round2 = (n: number) => Math.round(n * 100) / 100;

  return {
    totalSignals: trades.length,
    decidedTrades: decided.length,
    wins: wins.length,
    losses: losses.length,
    breakeven: breakeven.length,
    winRate: decided.length ? round2((100 * wins.length) / decided.length) : null,
    totalPnl: round2(totalPnl),
    grossProfit: round2(grossProfit),
    grossLoss: round2(grossLoss),
    profitFactor: grossLoss > 0 ? round2(grossProfit / grossLoss) : null,
    expectancy: decided.length ? round2(totalPnl / decided.length) : null,
    maxDrawdown: round2(maxDd),
    bestTradePnl: decided.length ? round2(Math.max(...decided)) : null,
    worstTradePnl: decided.length ? round2(Math.min(...decided)) : null,
  };
}

// ---------------------------------------------------------------------------
// Defect 6 — ranking eligibility

export interface StrategyStat {
  strategyId: string;
  strategyName: string;
  totalTrades: number;
  netPnl: number;
  winRate: number | null;
  profitFactor: number | null;
  avgR: number | null;
  maxDrawdown: number;
  consistency: number | null;
  compositeScore: number | null;
}

export interface RankingAward {
  key: string;
  label: string;
  note: string | null;
  strategyId: string | null;
  strategyName: string | null;
  value: string | null;
}

/**
 * A strategy must have >= minTrades decided trades to win ANY award.
 * Previously the ranking read byStrategy[0] regardless, so a 0-trade strategy
 * was crowned "Best Overall". The honest default for F&O research is 10 (your
 * existing comparison note already says "fewer than 10 trades are ineligible").
 */
export function rankStrategies(
  stats: StrategyStat[],
  minTrades = 10
): RankingAward[] {
  const eligible = stats.filter((s) => s.totalTrades >= minTrades);

  const pick = (
    key: string,
    label: string,
    metric: keyof StrategyStat,
    higherBetter: boolean,
    fmt: (v: number) => string,
    note: string | null = null
  ): RankingAward => {
    const cand = eligible.filter((s) => s[metric] != null);
    if (cand.length === 0) {
      return { key, label, note, strategyId: null, strategyName: null, value: null };
    }
    const best = cand.reduce((a, b) =>
      higherBetter
        ? (a[metric] as number) >= (b[metric] as number)
          ? a
          : b
        : (a[metric] as number) <= (b[metric] as number)
        ? a
        : b
    );
    return {
      key,
      label,
      note,
      strategyId: best.strategyId,
      strategyName: best.strategyName,
      value: fmt(best[metric] as number),
    };
  };

  const rupee = (n: number) => "\u20b9" + Math.round(n).toLocaleString("en-IN");
  const pct = (n: number) => n.toFixed(1) + "%";
  const num = (n: number) => n.toFixed(2);

  return [
    pick("OVERALL", "Best Overall (composite)", "compositeScore", true, num,
      "Multi-factor \u2014 not net profit alone."),
    pick("NET_PNL", "Best Net P&L", "netPnl", true, rupee),
    pick("WIN_RATE", "Best Win Rate", "winRate", true, pct),
    pick("PROFIT_FACTOR", "Best Profit Factor", "profitFactor", true, num),
    pick("DRAWDOWN", "Lowest Drawdown", "maxDrawdown", false, rupee),
    pick("AVG_R", "Best Avg R", "avgR", true, num),
  ];
}
