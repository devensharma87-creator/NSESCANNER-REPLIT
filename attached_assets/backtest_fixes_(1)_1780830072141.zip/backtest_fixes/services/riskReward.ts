/**
 * services/riskReward.ts
 * ---------------------------------------------------------------------------
 * Fixes the research-mode "everything blocks on minimumRiskReward" problem.
 *
 * Diagnosis from the data:
 *   - Emitted-signal SPOT R:R is healthy: median 2.22, only 8.6% below 1.5.
 *   - Yet research mode blocked ~49,844 setups on minimumRiskReward.
 *   - Cause: option columns are 0% populated (no historical premiums), so an
 *     option-premium R:R evaluates to a degenerate value and fails the gate.
 *
 * Fix: evaluate R:R on the OPTION premium when real premiums exist; otherwise
 * fall back to SPOT R:R (which is what the directional layer actually trades
 * via the labelled delta proxy). Never block a setup because the option layer
 * is unavailable — that's a data gap, not a risk failure.
 */

export interface RrInputs {
  spotEntry: number | null;
  spotStop: number | null;
  spotTarget1: number | null;
  optionEntry?: number | null;
  optionStop?: number | null;
  optionTarget1?: number | null;
}

export type RrBasis = "OPTION" | "SPOT" | "UNAVAILABLE";

export interface RrResult {
  ratio: number | null;
  basis: RrBasis;
  passes: boolean;
  reason?: string;
}

const valid = (v: number | null | undefined): v is number =>
  v != null && !Number.isNaN(v) && Number.isFinite(v);

/**
 * @param minRR  the UI "Min R:R" value (default 1.5).
 */
export function evaluateRiskReward(inp: RrInputs, minRR = 1.5): RrResult {
  // Prefer real option premiums.
  if (valid(inp.optionEntry) && valid(inp.optionStop) && valid(inp.optionTarget1)) {
    const risk = Math.abs(inp.optionEntry - inp.optionStop);
    const reward = Math.abs(inp.optionTarget1 - inp.optionEntry);
    if (risk > 0) {
      const ratio = reward / risk;
      return { ratio, basis: "OPTION", passes: ratio >= minRR };
    }
  }

  // Fall back to spot R:R when option premiums are absent.
  if (valid(inp.spotEntry) && valid(inp.spotStop) && valid(inp.spotTarget1)) {
    const risk = Math.abs(inp.spotEntry - inp.spotStop);
    const reward = Math.abs(inp.spotTarget1 - inp.spotEntry);
    if (risk > 0) {
      const ratio = reward / risk;
      return {
        ratio,
        basis: "SPOT",
        passes: ratio >= minRR,
        reason: "option premiums unavailable; evaluated on spot R:R",
      };
    }
  }

  // Genuinely no levels to evaluate. Don't silently block on a risk reason;
  // tag it as a DATA gap so it lands in the DATA category, not FILTER.
  return {
    ratio: null,
    basis: "UNAVAILABLE",
    passes: false,
    reason: "no entry/stop/target available (data gap, not a risk rejection)",
  };
}
