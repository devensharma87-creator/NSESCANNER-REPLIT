/**
 * services/signalWriter.ts
 * ---------------------------------------------------------------------------
 * Fixes Defect 1 — the ~29x duplicate storm.
 *
 * Root cause: the engine INSERTed a fno_signal_reasoning row on every poll
 * tick. The signal_fingerprint column existed but was never used to collapse
 * re-emissions, and the dedupe job never ran (its archive file is 0 bytes).
 *
 * This writer UPSERTs on signal_fingerprint: one row per unique signal,
 * always carrying the latest captured_at and lifecycle fields. Re-emissions
 * of the same signal update the existing row instead of inserting a new one.
 *
 * Constraints respected:
 *   - additive-only: new service; old insert path is replaced by calling this.
 *   - signal-enum separation: decision/lifecycle_status are stored as the raw
 *     enum; display labels are NOT written here.
 *   - paper-only: no order side effects.
 *
 * Requires a UNIQUE index on signal_fingerprint (see migrations/).
 */

import { sql } from "drizzle-orm";
import type { PgDatabase } from "drizzle-orm/pg-core";
import { fnoSignalReasoning } from "../db/schema"; // adjust path to your schema barrel

/** Stable fingerprint for a signal. Anything that identifies the SAME setup
 *  instance must be in here; nothing time-varying (no captured_at, no ltp). */
export function computeSignalFingerprint(s: {
  signalDate: string; // IST date key, not the poll timestamp
  indexSymbol: string;
  setupKey: string;
  direction: string;
  selectedStrike: number | string | null;
  spotEntry: number | string | null;
  spotStop: number | string | null;
  spotTarget1: number | string | null;
}): string {
  // Round price levels so micro-jitter between polls doesn't fork the fingerprint.
  const q = (v: number | string | null) =>
    v == null || v === "" ? "" : Math.round(Number(v) * 100) / 100;
  const parts = [
    s.signalDate,
    s.indexSymbol,
    s.setupKey,
    s.direction,
    q(s.selectedStrike),
    q(s.spotEntry),
    q(s.spotStop),
    q(s.spotTarget1),
  ];
  // djb2 -> hex; deterministic and dependency-free.
  let h = 5381;
  const str = parts.join("|");
  for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
  return (h >>> 0).toString(16).padStart(8, "0") + ":" + parts.length;
}

export interface SignalRowInput {
  capturedAt: Date; // poll instant (UTC)
  signalDate: string; // IST date key
  indexSymbol: string;
  indexName?: string;
  setupKey: string;
  direction: string;
  optionType?: string;
  tier?: string;
  decision: string; // raw enum, e.g. "EMITTED"
  reasonCode?: string;
  confidence?: number;
  confluenceScore?: number;
  regime?: string;
  vix?: number;
  spot?: number;
  spotEntry?: number;
  spotStop?: number;
  spotTarget1?: number;
  spotTarget2?: number;
  selectedStrike?: number;
  lifecycleStatus?: string;
  exitReason?: string;
  realizedPnl?: number;
  optionExit?: number;
  note?: string;
}

/**
 * Upsert one signal. Returns whether a new signal was created (true) or an
 * existing one was refreshed (false) — useful for the alerter so it only
 * notifies on genuinely-new signals, not on every poll.
 */
export async function upsertSignal(
  db: PgDatabase<any>,
  row: SignalRowInput
): Promise<{ fingerprint: string; isNew: boolean }> {
  const fingerprint = computeSignalFingerprint({
    signalDate: row.signalDate,
    indexSymbol: row.indexSymbol,
    setupKey: row.setupKey,
    direction: row.direction,
    selectedStrike: row.selectedStrike ?? null,
    spotEntry: row.spotEntry ?? null,
    spotStop: row.spotStop ?? null,
    spotTarget1: row.spotTarget1 ?? null,
  });

  // ON CONFLICT (signal_fingerprint) DO UPDATE — keep latest capture + lifecycle.
  // xmax = 0 trick tells us whether the row was inserted (new) or updated.
  const result = await db.execute(sql`
    INSERT INTO fno_signal_reasoning (
      captured_at, signal_date, index_symbol, index_name, setup_key, direction,
      option_type, tier, decision, reason_code, confidence, confluence_score,
      regime, vix, spot, spot_entry, spot_stop, spot_target1, spot_target2,
      selected_strike, lifecycle_status, exit_reason, realized_pnl, option_exit,
      note, signal_fingerprint
    ) VALUES (
      ${row.capturedAt}, ${row.signalDate}, ${row.indexSymbol}, ${row.indexName ?? null},
      ${row.setupKey}, ${row.direction}, ${row.optionType ?? null}, ${row.tier ?? null},
      ${row.decision}, ${row.reasonCode ?? null}, ${row.confidence ?? null},
      ${row.confluenceScore ?? null}, ${row.regime ?? null}, ${row.vix ?? null},
      ${row.spot ?? null}, ${row.spotEntry ?? null}, ${row.spotStop ?? null},
      ${row.spotTarget1 ?? null}, ${row.spotTarget2 ?? null}, ${row.selectedStrike ?? null},
      ${row.lifecycleStatus ?? null}, ${row.exitReason ?? null}, ${row.realizedPnl ?? null},
      ${row.optionExit ?? null}, ${row.note ?? null}, ${fingerprint}
    )
    ON CONFLICT (signal_fingerprint) DO UPDATE SET
      captured_at      = EXCLUDED.captured_at,
      confidence       = EXCLUDED.confidence,
      confluence_score = EXCLUDED.confluence_score,
      regime           = EXCLUDED.regime,
      vix              = EXCLUDED.vix,
      spot             = EXCLUDED.spot,
      lifecycle_status = COALESCE(EXCLUDED.lifecycle_status, fno_signal_reasoning.lifecycle_status),
      exit_reason      = COALESCE(EXCLUDED.exit_reason, fno_signal_reasoning.exit_reason),
      realized_pnl     = COALESCE(EXCLUDED.realized_pnl, fno_signal_reasoning.realized_pnl),
      option_exit      = COALESCE(EXCLUDED.option_exit, fno_signal_reasoning.option_exit),
      note             = EXCLUDED.note
    RETURNING (xmax = 0) AS is_new;
  `);

  const isNew = Boolean((result as any).rows?.[0]?.is_new);
  return { fingerprint, isNew };
}
