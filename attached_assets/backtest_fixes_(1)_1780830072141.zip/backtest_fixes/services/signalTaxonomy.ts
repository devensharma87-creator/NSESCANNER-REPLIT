/**
 * services/signalTaxonomy.ts
 * ---------------------------------------------------------------------------
 * Fixes F4, F5, F6 — the signal taxonomy / state-machine contradictions.
 *
 * F6  Tier bands overlapped: BASELINE conf reached 78, STANDARD sat at 72,
 *     HIGH_CONVICTION started at 69. A 75-confidence signal could be any tier.
 *     classifyTier() defines NON-OVERLAPPING bands as the single authority.
 *
 * F5  3,537 rows were decision=EMITTED AND reason=DEMOTED simultaneously.
 *     A demoted setup is not an emission. reconcileDecision() enforces the
 *     mutually-exclusive enum.
 *
 * F4  MISSED_WINDOW rows carried TARGET1_HIT/STOPPED outcomes. A signal that
 *     missed its entry window cannot have a fill result. isValidLifecycle()
 *     rejects the impossible transitions.
 *
 * Constraint: these operate on RAW enums only. Display labels (e.g. the badge
 * text the UI shows) are derived separately and never stored here.
 */

// ---- F6: tier authority ---------------------------------------------------
export type Tier = "BASELINE" | "STANDARD" | "HIGH_CONVICTION";

// Non-overlapping bands. Tune the thresholds to your engine's intent — the
// invariant that matters is that they do not overlap.
export const TIER_BANDS = {
  HIGH_CONVICTION: 70, // >= 70
  STANDARD: 60, // 60..69
  // BASELINE: < 60
} as const;

export function classifyTier(confidence: number | null | undefined): Tier | null {
  if (confidence == null || Number.isNaN(confidence)) return null;
  if (confidence >= TIER_BANDS.HIGH_CONVICTION) return "HIGH_CONVICTION";
  if (confidence >= TIER_BANDS.STANDARD) return "STANDARD";
  return "BASELINE";
}

/** Assert the bands don't overlap — guards against future threshold edits. */
export function assertTierBandsCoherent(): void {
  if (TIER_BANDS.HIGH_CONVICTION <= TIER_BANDS.STANDARD) {
    throw new Error("Tier bands overlap: HIGH_CONVICTION floor must exceed STANDARD floor");
  }
}

// ---- F5: decision is mutually exclusive -----------------------------------
export type Decision =
  | "EMITTED"
  | "DEMOTED"
  | "PRE_EMISSION_REJECTED"
  | "MISSED_WINDOW";

/**
 * A setup cannot be both emitted and demoted. If the reason says DEMOTED, the
 * decision is DEMOTED — not EMITTED.
 */
export function reconcileDecision(decision: string, reasonCode: string): Decision {
  if (decision === "EMITTED" && reasonCode === "DEMOTED") return "DEMOTED";
  return decision as Decision;
}

// ---- F4: lifecycle state machine ------------------------------------------
export type Lifecycle =
  | "" // not yet resolved
  | "PENDING"
  | "TRIGGERED"
  | "TARGET1_HIT"
  | "TARGET2_HIT"
  | "STOPPED"
  | "EXPIRED";

const TERMINAL_FILL: Lifecycle[] = ["TARGET1_HIT", "TARGET2_HIT", "STOPPED"];

/**
 * A lifecycle outcome is only valid if the signal was actually live.
 * MISSED_WINDOW / PRE_EMISSION_REJECTED signals never entered, so they cannot
 * carry a fill outcome.
 */
export function isValidLifecycle(decision: string, lifecycle: Lifecycle): boolean {
  if (lifecycle === "" || lifecycle === "EXPIRED") return true;
  const enteredMarket = decision === "EMITTED" || decision === "DEMOTED";
  if (TERMINAL_FILL.includes(lifecycle) && !enteredMarket) return false;
  return true;
}

/** Sanitize a lifecycle value against its decision; returns the safe value. */
export function sanitizeLifecycle(decision: string, lifecycle: Lifecycle): Lifecycle {
  return isValidLifecycle(decision, lifecycle) ? lifecycle : "";
}
